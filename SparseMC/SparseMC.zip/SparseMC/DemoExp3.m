% The smooth formulation part of Experiment-3 in 'A Multichannel Audio Denoising Formulation Based on Spectral Sparsity'
% Ilker Bayram
% ibayram@itu.edu.tr
% Istanbul Technical University, 2014

clear all;
close all;

load DatExp3

% loaded variables : 
%   x : clean signal (for computing the SNR)%   
%   y : noisy observations
%   win : window used for the STFT
%   Hop : Hop-size for the STFT
%   fs : sampling frequency

SNR = @(x,y) 10*log10( sum(abs(x).^2)/sum(abs(x-y).^2)); % computes the SNR given the clean signal (x) and the noisy signal (y)

N = 3; % number of observations

for n = 1:N,
    wy{n} = STFT(y{n},win,Hop);
end

% parameters for the fusion stage
pa.len = 2; % the time span (number of coefficients along the time axis) of the blocks used in the fusion stage
pa.wdt = 2; % the frequency span of the blocks used in the fusion stage
pa.lam = 0.5; % lambda parameter (weight of the regularization term) in eqn (16)
pa.MAX_ITER = 500; % number of iterations in the Algorithm (the reported SNRs can be reached with 1000 iterations)
pa.gam1 = 100;
pa.gam2 = 200;
pa.st = 0.5;

% 1) fusion
[wz,aR,cost] = SmoothFormBlockPG(wy,pa); % smooth formulation in the STFT domain
z = ISTFT(wz,win,Hop);z = real(z(1:length(x))); % the fused signal in the time domain

% 2) Estimation of the remaining amount of noise
dinv = aR{1}.*(abs(wy{1} - wz).^2) + aR{2}.*(abs(wy{2} - wz).^2) + aR{3}.*(abs(wy{3} - wz).^2); %this is
dinv = dinv/(N-1);

% 3) Post-filter
wzPF = PostFilter(wz,dinv); % block postfilter
F = (abs(wzPF).^2)./(abs(wzPF).^2 + dinv + 10^(-10)); % Wiener post-filter

wzPFW = F.*wz; % post-filtered STFT coefficients
zPFW = ISTFT(wzPFW,win,Hop); zPFW = real(zPFW(1:length(x))); % final reconstruction in the time domain

% figures...

% cost function
figure;plot(cost);xlabel('Iterations');title('Cost wrt Iterations');axis tight;

wx = STFT(x,win,Hop);
Norm = max(abs(wx(:)));

lim = round(3000*length(win)/fs); % view up to 3Khz in the spectrogram
% clean signal
[s,f,t] = spectrogram(x,win,length(win)-Hop,length(win),fs);
figure; imagesc(t,f(1:lim),log(abs(s(1:lim,:)))); xlabel('Time (sec)'); ylabel('Frequency (Hz)');
title('Clean Signal');

% observations
[s,f,t] = spectrogram(y{1},win,length(win)-Hop,length(win),fs);
figure; imagesc(t,f(1:lim),log(abs(s(1:lim,:)))); xlabel('Time (sec)'); ylabel('Frequency (Hz)'); 
title(strcat('Observation 1, SNR = ',num2str(SNR(x,y{1}))));

[s,f,t] = spectrogram(y{2},win,length(win)-Hop,length(win),fs);
figure; imagesc(t,f(1:lim),log(abs(s(1:lim,:)))); xlabel('Time (sec)'); ylabel('Frequency (Hz)'); 
title(strcat('Observation 2, SNR = ',num2str(SNR(x,y{2}))));

% the fused signal
[s,f,t] = spectrogram(z,win,length(win)-Hop,length(win),fs);
figure; imagesc(t,f(1:lim),log(abs(s(1:lim,:)))); xlabel('Time (sec)'); ylabel('Frequency (Hz)'); 
title(strcat('The Fused Signal, SNR = ',num2str(SNR(x,z))));

% Reconstruction after Post-filtering
[s,f,t] = spectrogram(zPFW,win,length(win)-Hop,length(win),fs);
figure; imagesc(t,f(1:lim),log(abs(s(1:lim,:)))); xlabel('Time (sec)'); ylabel('Frequency (Hz)'); 
title(strcat('Reconstruction after Post-filtering, SNR = ',num2str(SNR(x,zPFW))));

% weights estimated by the fusion stage
figure; imagesc(t,f(1:lim),aR{1}(1:lim,1:length(t))); colormap(1-colormap(gray)); xlabel('Time (sec)'); ylabel('Frequency (Hz)'); 
title('\alpha_1(k,s)');

figure; imagesc(t,f(1:lim),aR{2}(1:lim,1:length(t))); colormap(1-colormap(gray)); xlabel('Time (sec)'); ylabel('Frequency (Hz)'); 
title('\alpha_2(k,s)');

figure; imagesc(t,f(1:lim),aR{3}(1:lim,1:length(t))); colormap(1-colormap(gray)); xlabel('Time (sec)'); ylabel('Frequency (Hz)'); 
title('\alpha_3(k,s)');