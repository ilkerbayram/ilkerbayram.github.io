function [alp] = ProjectAlpha(bet)
% finds the closest a1, a2, ... , to bet1, bet2, ... such that
% sum a(i) = 1, a(i) >= 0.
%

% Reference : 'Efficient projections onto the l1 ball for learning in high
%               dimensions', by J. Duchi, S. Shalev-Shwartz, Y. Singer and
%               T. Chandra
%
% Matlab code written by Ilker Bayram, ibayram@itu.edu.tr
% Istanbul Technical University, 2014

d = size(bet,1); % dimension

% sort bet
m = sort(bet,1,'descend');
th = zeros(1,size(bet,2));

cs = cumsum(m,1);
cs = (cs - 1);
for r = 1:d,
    t = cs(r,:)/r;
    ind = (m(r,:) - t) > 0;
    th(ind) = t(ind);
end
alp = bet - ones(size(bet,1),1)*th;

alp = max(alp,0);