function [Sout] = PostFilter(S,sig)
%function [Sout] = PostFilter(S,sig)
%
%%% input variables %%%
% S : the noisy STFT coefficients
% sig : the noise variance field
%
%%% output variable %%%
% Sout : denoised STFT coefficients
%
% Ilker Bayram
% ibayram@itu.edu.tr
% Istanbul Technical University, June 2014

% block size : LxW
L = 8;
W = 64;

eps = 10^(-8);
lam = 1;

SM = abs(S).^2;

Sout = S; % initialization

% loop over the blocks of size LxW
for r = 1:W:size(S,1)-W-1,
	for c = 1:L:size(S,2)-L-1,
		B = SM(r:r+W-1,c:c+L-1);
		sigB = sig(r:r+W-1,c:c+L-1);
        invNorm = 0;
        % loop over different subblock shapes to see which one fits the
        % data better
		for n = 0:3,
			len = 2^n;
			wdt = 2^(4-n);
			norm = upfirdn(B,ones(wdt,1));
            norm = norm(wdt:wdt:end,:);
			norm = upfirdn(norm',ones(len,1));
            norm = norm(len:len:end,:);            
			Cnorm = [ sum(sqrt(norm(:))) ]^(-1);
			if Cnorm > invNorm,
				invNorm = Cnorm;
				Blen = len;
				Bwdt = wdt;
                Bnorm = norm;
			end
        end
		% at the end of the loop, Blen and Bwdt hold the size of the
		% subblocks
        
        % determine the average noise variance on each subblock
		sigB = upfirdn(sigB,ones(Bwdt,1));
        sigB = sigB(Bwdt:Bwdt:end,:);
        sigB = upfirdn(sigB',ones(Blen,1));
        sigB = sigB(Blen:Blen:end,:);
        
		ksi = max((Bnorm./(sigB+eps))-1,0);
		a = max(1 - lam./(ksi + 1),0);
		a = [a; zeros(1,size(a,2))];
        a = upfirdn(a,ones(Blen,1),Blen,1); 
        a = a(1:end-Blen,:); 
		a = [a'; zeros(1,size(a,1))];        
        a = upfirdn(a,ones(Bwdt,1),Bwdt,1);
        a = a(1:end-Bwdt,:); 
		
	
		Sout(r:r+W-1,c:c+L-1) = S(r:r+W-1,c:c+L-1).*a;

	end
end