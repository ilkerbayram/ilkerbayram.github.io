% Experiment-2 in 'A Multichannel Audio Denoising Formulation Based on Spectral Sparsity'
% Ilker Bayram
% ibayram@itu.edu.tr
% Istanbul Technical University, 2014


clear all;
close all;

load DatExp2

% loaded variables : 
%   x : clean signal (for computing the SNR)%   
%   y : noisy observations
%   win : window used for the STFT
%   Hop : Hop-size for the STFT
%   fs : sampling frequency
%   d1, d2 : time-varying noise variance for the two observations

SNR = @(x,y) 10*log10( sum(abs(x).^2)/sum(abs(x-y).^2)); % computes the SNR given the clean signal (x) and the noisy signal (y)

for n = 1:2,
    wo{n} = STFT(y{n},win,Hop);
end

% parameters for the fusion stage
pa.len = 1; % the time span of the blocks used in the fusion stage
pa.wdt = 512; % the frequency span of the blocks used in the fusion stage
pa.lam = 1; % lambda parameter (weight of the regularization term) in eqn (16)
pa.MAX_ITER = 50; % number of iterations in the Algorithm


% 1) fusion
[wz,aR,cost] = SmoothFormBlockPG(wo,pa); % smooth formulation in the STFT domain
z = ISTFT(wz,win,Hop);z = real(z(1:length(x))); %the fused signal in the time domain


% 2) Estimation of the remaining amount of noise
dinv = aR{1}.*(abs(wo{1} - wz).^2) + aR{2}.*(abs(wo{2} - wz).^2); %this is
dinv = ones(size(wz,1),1)*mean(dinv); %this is specific to the noise pattern in this experiment -- we know that the noise is white with time-varying variance

% 3) Post-filter
wzPF = PostFilter(wz,dinv); % block postfilter
F = (abs(wzPF).^2)./(abs(wzPF).^2 + dinv + 10^(-10)); % Wiener post-filter

wzPFW = F.*wz; % post-filtered STFT coefficients
zPFW = ISTFT(wzPFW,win,Hop); zPFW = real(zPFW(1:length(x))); % final reconstruction in the time domain

% figures...

% cost function
figure;plot(cost);xlabel('Iterations');title('Cost wrt Iterations');axis tight;




lim = round(3000*length(win)/fs); % view up to 3Khz in the spectrogram
% clean signal
[s,f,t] = spectrogram(x,win,length(win)-Hop,length(win),fs);
figure; imagesc(t,f(1:lim),log(abs(s(1:lim,:)))); xlabel('Time (sec)'); ylabel('Frequency (Hz)');
title('Clean Signal');

% observations
[s,f,t] = spectrogram(y{1},win,length(win)-Hop,length(win),fs);
figure; imagesc(t,f(1:lim),log(abs(s(1:lim,:)))); xlabel('Time (sec)'); ylabel('Frequency (Hz)'); 
title(strcat('Observation 1, SNR = ',num2str(SNR(x,y{1}))));

[s,f,t] = spectrogram(y{2},win,length(win)-Hop,length(win),fs);
figure; imagesc(t,f(1:lim),log(abs(s(1:lim,:)))); xlabel('Time (sec)'); ylabel('Frequency (Hz)'); 
title(strcat('Observation 2, SNR = ',num2str(SNR(x,y{2}))));

% the fused signal
[s,f,t] = spectrogram(z,win,length(win)-Hop,length(win),fs);
figure; imagesc(t,f(1:lim),log(abs(s(1:lim,:)))); xlabel('Time (sec)'); ylabel('Frequency (Hz)'); 
title(strcat('The Fused Signal, SNR = ',num2str(SNR(x,z))));

% Reconstruction after Post-filtering
[s,f,t] = spectrogram(zPFW,win,length(win)-Hop,length(win),fs);
figure; imagesc(t,f(1:lim),log(abs(s(1:lim,:)))); xlabel('Time (sec)'); ylabel('Frequency (Hz)'); 
title(strcat('Reconstruction after Post-filtering, SNR = ',num2str(SNR(x,zPFW))));


% optimal weights
alp1 = d1.^(-2) ./ (d1.^(-2) + d2.^(-2));
alp2 = d2.^(-2) ./ (d1.^(-2) + d2.^(-2));
%

tn = (0:length(x)-1)/fs;
tm = (1:size(aR{1},2))*max(tn)/size(aR{1},2);

figure;
plot(tn,alp1,'--');hold on;
plot(tn,alp2,'r--');
plot(tm,mean(aR{1}));
plot(tm,mean(aR{2}),'r');
axis tight;
xlabel('Time (seconds)');
title('Optimal weights (dashed) vs. the ones found by the Fusion Stage (solid)');

% remaining noise variance
wx = STFT(x,win,Hop); % STFT of the clean signal
actual = (abs(wx - wz)).^2; % this is the remaining noise over the whole T-F plane
actual = mean(actual); % average over frequency
figure;
plot(tm,actual);hold on;plot(tm,mean(dinv),'r');
axis tight;
xlabel('Time (seconds)');
title('Remaining Noise Variance : Actual (Blue), Estimated (Red)');