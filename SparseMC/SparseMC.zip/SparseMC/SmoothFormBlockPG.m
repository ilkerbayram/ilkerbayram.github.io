function [Z,alp,varargout] = SmoothFormBlockPG(X,param)
% function [Z,alp,varargout] = SmoothFormBlockPG(X,param)
% Description : 'Smooth formulation' with the projected gradient algorithm as
% descrribed in 'A Multichannel Audio Denoising Formulation Based on Spectral Sparsity'
%
%%% input variables
% X : a cell array where each element holds the STFT coefficients of an
%   observation
% param : a structure array that holds the algorithm parameters with the following fields
%   param.len : the time span of the blocks used in the fusion stage
%   param.wdt : the frequency span of the blocks used in the fusion stage
%   param.lam : the lambda parameter (weight of the regularization term) in eqn (16)
%   param.MAX_ITER : number of iterations in Algorithm-1
%   param.st, param.gam1, param.gam2 : the value of the stepsize is decided
%   according to the rule "beta = param.st*param.st*(param.gam1/(param.gam2 + iteration_count))"
%
%%% output variables %%%
% Z : the STFT coefficients output by the fusion stage
% alp : the weight coefficients estimated by the fusion stage
% varargout : if desired, the cost at each iteration is returned
%
% Ilker Bayram
% ibayram@itu.edu.tr
% Istanbul Technical University, June 2014

existfield = @(x,y) max(strcmp(fieldnames(x),y));

if ~existfield(param,'gam1'),
    param.gam1 = 100;
end

if ~existfield(param,'gam2'),
    param.gam2 = 100;
end

if ~existfield(param,'st'),
    param.st = 0.1;
end


lam = param.lam;
len = param.len;
wdt = param.wdt;

N = length(X); % N is the number of observations

R = size(X{1},1); 
C = size(X{1},2); 
RR = round(R/2);
%%%
for n = 1:N,
    alp{n} = ones(RR,C)/N;
end

red = alp{1}(1:wdt:end,1:len:end);
a = zeros(1,length(red(:)));

MAX_ITER = param.MAX_ITER;



wb = waitbar(0);


cost = zeros(1,MAX_ITER);
    
for it = 1:MAX_ITER,
    waitbar(it/MAX_ITER,wb,strcat(num2str(round(100*it/MAX_ITER)),'%'));      
    
    bet = param.st*(param.gam1/(param.gam2 + it)); %this is the step size at the current iteration
    
    % compute the gradient
    
    % first the l1 term
    d = X{1}(1:RR,1:C).*alp{1};
    for n = 2:N,
        d = d + X{n}(1:RR,1:C).*alp{n};
    end
    cost(it) = sum(abs(d(:))); % update cost (could be turned off if not required by the user)
    d = d./abs(d);
    
    for n = 1:N,
        gr = real( (conj( X{n}(1:RR,1:C) )).*d );
        gr = conv2(gr,ones(wdt,len));
        gr = gr(wdt:wdt:end,len:len:end);
        grad{n} = gr;
    end
    
    % now the local difference term
    
    for n = 1:N;
        alpred{n} = alp{n}(1:wdt:end,1:len:end);
        alp1 = [alpred{n}(1,:); alpred{n}(1:end-1,:)];
        cost(it) = cost(it) + lam*(sum(sum((alpred{n}-alp1).^2)));
        reg = alp1;        
        
        alp1 = [alpred{n}(2:end,:); alpred{n}(end,:)];
        cost(it) = cost(it) + lam*(sum(sum((alpred{n}-alp1).^2)));
        reg = reg + alp1;
        
        alp1 = [alpred{n}(:,1) alpred{n}(:,1:end-1)];
        cost(it) = cost(it) + lam*(sum(sum((alpred{n}-alp1).^2)));
        reg = reg + alp1;
        
        alp1 = [alpred{n}(:,2:end) alpred{n}(:,end)];
        cost(it) = cost(it) + lam*(sum(sum((alpred{n}-alp1).^2)));
        reg = reg + alp1;
        
        grad{n} = grad{n} + 2*lam*(4*alpred{n} - reg);        
        alpred{n} = alpred{n} - bet*grad{n};
    end
    
    
    for n = 1:N,
        a(n,:) = alpred{n}(:);
    end
    
    %projection onto the unit simplex
    a = ProjectAlpha(a);
    
    % update alp
    
    for n = 1:N,
        dat = a(n,:);
        dat = reshape(dat,size(alpred{1},1),size(alpred{1},2));
        dat = kron(dat,ones(wdt,len));
        alp{n} = dat(1:size(alp{1},1),1:size(alp{1},2));
    end
    
   
end
close(wb);
% the optimal weights are computed for each block

Z = zeros(size(X{1})); % will hold the STFT coefficients of the fused signal
a = ones(size(X{1}))/N; 
for n = 1:N,
    a(1:RR,:) = alp{n}; 
    a(end:-1:end/2+2,:) = a(2:end/2,:);    
    Z = Z + X{n}.*a;
    alp{n} = a;
end


if nargout>2,
    varargout{1} = cost;
end