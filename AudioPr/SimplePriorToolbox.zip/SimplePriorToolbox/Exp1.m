% Experiment-1 in 'A Simple Prior For Audio Signals', 
% Ilker Bayram and Mustafa Kamasak.
%
% Istanbul Technical University, 2012

clear all;
close all;


[obs,fs,nbits] = wavread('TanburExcerpt.wav');

xx = obs;
K = 5000;
obs  = [ zeros(K,1); obs; zeros(K,1)]; % pad with zeros
sig = 0.005;
obs = obs + sig*randn(size(obs));% this is the noisy observation

% STFT parameters
N = 4096;
Hop = 256;
win = Hamming(N);
win = NormalizeW(win,Hop);

wobs = STFT(obs,win,Hop);

z = 0*wobs;

MAX_ITER = 100;
lam = 0.008;

x = DenoiseSimplePrior(obs,lam,win,Hop,MAX_ITER);

% % this normalization step further boosts the SNR but does not affect the
% % sound quality
% ex = sqrt(sum(abs(x).^2));
% exx = sqrt(sum(abs(xx).^2));
% x = x*exx/ex;


x2 = obs(K+1:end-K);
SNRin =  10*log10(sum(xx(:).^2) / (sum((xx(:)-x2(:)).^2)))

x2 =  x(K+1:end-K);
SNRout =  10*log10(sum(xx(:).^2) / (sum((xx(:)-x2(:)).^2)))

% STFT parameters
N = 2048;
Hop = 128;
win = Hamming(N);
win = NormalizeW(win,Hop);

wobs = STFT(obs(K:end-K),win,Hop);
M = max(abs(wobs(:)));
wobs = wobs/M;
Clim = [-50,0];

figure;subplot(1,2,1);
cdb = 20*log10(abs(wobs(end/4:-1:1,:)));
imagesc(cdb,Clim);
title('Observed Signal''s Spectrogram');
set(gca,'XTick',[]);
set(gca,'YTick',[]);
xlabel('Time');
ylabel('Frequency');



w = STFT(x(K:end-K),win,Hop);
w = w/M;
subplot(1,2,2);
cdb = 20*log10(abs(w(end/4:-1:1,:)));
imagesc(cdb,Clim);
title('Denoised Signal''s Spectrogram');
set(gca,'XTick',[]);
set(gca,'YTick',[]);
xlabel('Time');
ylabel('Frequency');