function [x] = DenoiseSimplePrior(obs,lam,win,Hop,varargin)
%
% Implements Algorithm 1 in 'A Simple Prior For Audio Signals', 
% Ilker Bayram and Mustafa Kamasak.
%
% Input Variables : 
% obs : noisy observation
% lam : the lambda parameter in eq.(29)
% win : window used in the STFT
% Hop : Hop size for the STFT
% varargin : number of iterations
%
% Output Variable : 
% x : denoised signal
%
% Istanbul Technical University, 2012




% STFT parameters
N = length(win);

MAX_ITER = 50;  
if ~isempty(varargin),
    MAX_ITER = varargin{1};
end

ro = 1/(lam^2);

for c = 0:N-1,    
    H(:,c+1) = [1; -exp(1i*2*pi/N*Hop*c)];
end
G = conj(H(end:-1:1,:));

z = STFT(0*obs,win,Hop);

wb = waitbar(0);
figure;
for iter = 1:MAX_ITER,
    waitbar(iter/MAX_ITER,wb,strcat(num2str(round(100*iter/MAX_ITER)),'%'));        
       
    % apply D' to z
    zz = z.';
    zz = upfirdn(zz,G,1,1);zz = zz(1:end-1,:);
    zz = zz.';
    % apply A to (D' z)
    t = ISTFT(zz,win,Hop); t = real(t(1:length(obs)));
    
    u = obs-lam*t;
    plot(lam*t);drawnow;
    
    zz1 = STFT(u,win,Hop);
    zz = zz1.';
    zz = upfirdn(zz,H,1,1);zz = zz(2:end,:);
    zz = zz.';
    
    zz = z + ro*lam*zz;
    
    m = abs(zz);
    m = min(1./m,1);
    z = zz.*m;    
end
close(wb);


x = obs - lam*t;