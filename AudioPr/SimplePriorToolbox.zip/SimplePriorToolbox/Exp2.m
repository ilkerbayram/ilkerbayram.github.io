% Experiment-2 in 'A Simple Prior For Audio Signals', 
% Ilker Bayram and Mustafa Kamasak.
%
% Istanbul Technical University, 2012

clear all;
close all;


[obs,fs,nbits] = wavread('glockenspiel.wav');
K = 2048;
obs = [zeros(K,1); obs; zeros(K,1)]; % pad with zeros



% algorithm parameters

% STFT parameters
N = 4096;
Hop = 256;
win = Hamming(N);
win = NormalizeW(win,Hop);

wobs = STFT(obs,win,Hop);

z = 0*wobs;


lam = 0.05;

x = DenoiseSimplePrior(obs,lam,win,Hop);

% STFT parameters
N = 2048;
Hop = 128;
win = Hamming(N);
win = NormalizeW(win,Hop);

wobs = STFT(obs,win,Hop);
M = max(abs(wobs(:)));
wobs = wobs/M;

Clim = [-50,0];
cdb = 20*log10(abs(wobs(end/4:-1:1,:)));
figure;subplot(2,1,1);
imagesc(cdb,Clim);
title('Observed Signal''s Spectrogram');
set(gca,'XTick',[]);
set(gca,'YTick',[]);
xlabel('Time');
ylabel('Frequency');



w = STFT(x,win,Hop);
w = w/M;
subplot(2,1,2);
cdb = 20*log10(abs(w(end/4:-1:1,:)));
imagesc(cdb,Clim);
title('Denoised Signal''s Spectrogram');
set(gca,'XTick',[]);
set(gca,'YTick',[]);
xlabel('Time');
ylabel('Frequency');



figure;subplot(2,1,1);plot(obs);axis tight;
figure;subplot(2,1,1);plot(obs-x);axis tight;