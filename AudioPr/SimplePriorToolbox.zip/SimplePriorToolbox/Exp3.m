% Audio Inpainting Experiment
%
% Ilker Bayram
% ibayram@itu.edu.tr
% Istanbul Technical University, 2012

clear all;
close all;

[x,fs,nbits] = wavread('TanburExcerpt.wav');
x = x-mean(x);
original = x;

maskt = ones(length(x),1); % mask used to set some samples to zero
imaskt = zeros(length(x),1); % inverse of the mask

for k = 5000:3000:length(x)-500,
    maskt(k:k+500)=0;
    imaskt(k:k+500)=1;
end

y = x.*maskt; % the observed signal with missing segments

% the STFT parameters used for reconstruction
N = 4096;
Hop = 512;
win = hann(N);
win = NormalizeW(win,Hop);



% algorithm parameters
MAX_ITER = 1000;
gam = 2;

H = zeros(2,N);
for c = 0:N-1,    
    H(:,c+1) = [1; -exp(1i*2*pi/N*Hop*c)];
end
G = conj(H(end:-1:1,:));


x = 0*y;
z = STFT(0*y,win,Hop);  


figure;
wb = waitbar(0);
for iter = 1:MAX_ITER,
    waitbar(iter/MAX_ITER,wb,strcat(num2str(round(100*iter/MAX_ITER)),'%'));    
    
    % Primal Step
    
    % apply D' to z
    zz = z.';
    zz = upfirdn(zz,G,1,1);zz = zz(1:end-1,:);
    zz = zz.';
    % apply A to (D' z)
    t = ISTFT(zz,win,Hop); t = real(t(1:length(y)));
    
    x = x - gam*t;
    x = y.*maskt + x.*imaskt;
    
    % Dual Step
    
    zz1 = STFT(x,win,Hop);
    zz = zz1.';
    zz = upfirdn(zz,H,1,1);zz = zz(2:end,:);
    zz = zz.';
    
    zz = z + gam*zz;
    
    m = abs(zz);
    m = min(1./m,1);
    z = zz.*m;
    
    clf;
    plot(original(49500:51000));hold on;plot(x(49500:51000),'r');axis tight;
    title('Blue : Original, Red : Current Reconstruction');    
    drawnow;
end
close(wb);
close;



% STFT parameters for the plots
N = 2048;
Hop = 128;
win = Hamming(N);
win = NormalizeW(win,Hop);

wy = STFT(y,win,Hop);
wx = STFT(original,win,Hop);
M = max(abs(wx(:)));
wx = wx/M;
wy = wy/M;

Clim = [-50, 0];
figure;
cdb = 20*log10(abs(wx(end/4:-1:1,:)));
imagesc(cdb,Clim);
title('Original Signal''s Spectrogram');

figure;
cdb = 20*log10(abs(wy(end/4:-1:1,:)));
imagesc(cdb,Clim);
title('Observed Signal''s Spectrogram');

w = STFT(x,win,Hop);
w = w/M;
figure;
cdb = 20*log10(abs(w(end/4:-1:1,:)));
imagesc(cdb,Clim);
title('Reconstructed Signal''s Spectrogram');

figure;plot(original);hold on;plot(x,'r');
title('Blue : Original, Red : Reconstruction');

figure;
subplot(2,1,1);plot(49500:51000,original(49500:51000));hold on;plot(49500:51000,x(49500:51000),'r');axis tight;
title('Blue : Original, Red : Reconstruction');
subplot(2,1,2);plot(52500:54000,original(52500:54000));hold on;plot(52500:54000,x(52500:54000),'r');axis tight;

