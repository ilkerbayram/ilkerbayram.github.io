function [xSt] = TimeScaleInterpol(x,rNum,rDen,p,q,s,L,varargin)
%time scale audio signal by 'ratio = rNum/rDen'
%p, q, s : rational sampling factors of the transform
%L : number of stages

r = s;
if nargin>7,
    r = varargin{1};
end

ratio = rNum/rDen;

w = DWT_FFT(x,L,p,q,s,r);
wd = DUAL_DWT_FFT(x,L,p,q,s,r);

xSt = zeros(1,round(length(x)*ratio)); %zero signal, to be filled in...

wy = DWT_FFT(xSt,L,p,q,s,r); %replace this line by an zero wavelet coefficient template
wyd = wy;

cntr = FindCntr(p,q,r,L); %the center frequencies
tstp = s*( (q/p).^(0:L-1) ); %time increase between each sample

len = length(w{1});

for n = 2:L-1, %exclude the highpass and lowpass channels

    len = len*(p/q);
    len2 = len*ratio; %expected length for the new subband
    
    sub = w{n}+j*wd{n};
    c = abs(sub);
    a = angle(sub);
    phDif = conv(a,[1 -1]);
    phDif = phDif + cntr(n)*tstp(n); %subtract the phase contribution due to center frequency
    %take the principal value (i.e. restrict to +-pi)
    phDif = phDif - 2*pi*round(phDif/(2*pi));
    phDif = phDif/tstp(n);% - cntr(n);

    ph = a(1); %accumulate phase here
    for k = 0:min(len2,length(wy{n})-1),
        kk = floor(k/ratio)+1;
        tau = kk - k/ratio;
        c2 = (1-tau)*c(kk) + tau*c(kk+1);
        a2 = (1-tau)*phDif(kk) + tau*phDif(kk+1);
        a2 = a2 - cntr(n);
        ph = ph + a2*tstp(n);
        sub1(k+1) = c2*cos(ph);
        sub2(k+1) = c2*sin(ph);
    end
    ln2 = min(length(sub1),length(wy{n}));
    wy{n}(1:ln2) = sub1(1:ln2);
    wyd{n}(1:ln2) = sub2(1:ln2);
    
end

y1 = IDWT_FFT(wy,p,q,s,r);
y2 = DUAL_IDWT_FFT(wyd,p,q,s,r);

xSt = real((y1+y2))/2;