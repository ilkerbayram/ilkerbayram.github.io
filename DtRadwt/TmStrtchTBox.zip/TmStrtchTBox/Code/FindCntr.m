function [cnt] = FindCntr(p,q,s,K)
%determines the center frequency of the bandpass filter upto stage L (in
%radians) for the given parameters
%currently the first stage is set to pi...

cnt = [pi];
%cnt2 = [pi];
if (1/s + (p/q)^2) < 1,
    base = 0.5*( 1 - 1/s + p/q )*pi*sqrt(p/q);
    for n = 2:K,
        cnt = [cnt ( (p/q)^(n-2) )* base];
    end
    return;
end



f = [ 0.48296291314453   0.83651630373781   0.22414386804201  -0.12940952255126]/sqrt(2);

tet = @(w) ( abs( f(1) + f(2)*exp(j*w) + f(3)*exp(j*2*w) + f(4)*exp(j*3*w) ) );
   
b1lo = pi*(1-1/s)/p;
b1hi = pi/q;
b1w = b1hi - b1lo;

c1 = sqrt(p*q);

H = @(w) ( c1*(mod(w,2*pi) < b1lo )  + c1*( tet( pi*(w - b1lo)/b1w ) .* (mod(w,pi)<=b1hi) .* (mod(w,pi)>= b1lo ) ) );

c2 = sqrt(s);

G = @(w) ( c2*sqrt(c1^2 - H(w/p).^2)/c1);

del = 1/5000;
w = 0:del:pi;

Iter = K;

HH = ones(size(w));
fr = 1/p;
for L = 1:K-1,
    
    HH = HH.*H(fr*w);
    GG = HH.*G(q^L * p^(-L) * w);
    fr = fr*q/p;
    [m,in] = max(GG);
    cnt = [cnt w(in)];
%    w2 = w.*(sqrt(2)*GG > m );
%    in2 = max(w2);
%    w2 = w - in2;w2 = -(sqrt(2)*GG > m ).*w2;
%    [m,in] = max(w2);
%    in2 = sqrt(in2*w(in));
%    cnt2 = [cnt2 in2];
    
end