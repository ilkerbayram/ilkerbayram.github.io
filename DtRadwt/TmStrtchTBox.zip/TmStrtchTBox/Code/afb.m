function [lo, hi] = afb(x, H0, H1, p, q, s);
% [lo, hi] = afb(x);
% Analysis filter bank - overcomplete rational FB
% x - data
% length(x) must be a multiple of 2*q*s (?)
% H0, H1 - low-pass and high-pass frequency responses
% length(H0) should equal p*length(x)
% length(H1) should equal length(x)
%
%
% % Example:
% N = 48;
% p = 3;
% q = 4;
% s = 2;
% [H0,H1] = MakeFreqResp(N,p,q,s);
% x = zeros(1,N);
% x(1:10) = rand(1,10);
% [lo,hi] = afb(x, H0, H1, p, q, s);
% y = sfb(lo, hi, H0, H1, p, q, s);
% e = x - y(1:N);
% max(abs(e))

X = fft(x);

X0 = kron(ones(1,p),X);

% low-pass subband
X0 = X0.*H0;

N = length(X0)/q;
for n = 1:q-1,
    X0(N+1:2*N) = X0(1:N) + X0(N+1:2*N);
    X0 = X0(N+1:end);
end

lo = ifft(X0(1:N)/q);

% high-pass subband

Y0 = X.*H1;
N = length(Y0)/s;
for n = 1:s-1,
    Y0(N+1:2*N) = Y0(1:N) + Y0(N+1:2*N);
    Y0 = Y0(N+1:end);
end

hi = ifft(Y0(1:N)/s);
