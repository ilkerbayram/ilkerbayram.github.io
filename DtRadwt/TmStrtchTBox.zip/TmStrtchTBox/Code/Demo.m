clear all;
close all;

%input signal
[x,fs,nbits] = wavread('../AudioFiles/D_Gypsy-run-up_150.wav');
x = x(:)';


% parameters for the DtRadwt - it should be ensured that r >= s
 % sampling factors
 p = 7; q = 8; s = 2;  r = s+2;
 % number of stages
 L = 50;
 
% time-scale by rNum/rDen
rNum = 3;
rDen = 4;

% 'TimeScaleInterpol' is the main function...
[xSt] = TimeScaleInterpol(x,rNum,rDen,p,q,s,L,r);

soundsc(x,fs);
soundsc(xSt,fs);