function w = DWT_FFT(x,L,p,q,s,varargin)
% DWT using the overcomplete rational FB
% x : input
% L : number of stages
% p,q,r,s : sampling factors for the FB below
%  ----- U(p) -- H0 -- D(q)-->
%    |
%     -- U(r) -- H1 -- D(s)-->
% note : currently only r=1 is supported
%
%   N = 20;
%   x = rand(1,N);
%   J = 3;
%   p = 3; q = 4; s = 2;
%   w = DWT_FFT(x, J, p, q, s);
%   y = IDWT_FFT(w, p, q, s);
%   e = x - y(1:N);
%   max(abs(e))
%
%   p = 5; q = 6; s = 2;
%   w = DWT_FFT(x, J, p, q, s);
%   y = IDWT_FFT(w, p, q, s);
%   e = x - y(1:N);
%   max(abs(e))

r = s;
if nargin > 5,
    r = varargin{1};
end

sig = x;
for j = 1:L,
    len = length(sig);
    po = ceil(len/(2*q*s));
    N = (2*q*s)*po;
    y = zeros(1,N);
    y(1:len) = sig;
%   [H0,H1] = MakeFreqResp(N,p,q,s);%this is the original
    [H0,H1] = MakeFreqResp(N,p,q,s,r-s);%comment out this line to go back to the original
    [lo,hi] = afb(y,H0,H1,p,q,s);
    w{j} = hi;
    sig = lo;
end
w{L+1} = lo;