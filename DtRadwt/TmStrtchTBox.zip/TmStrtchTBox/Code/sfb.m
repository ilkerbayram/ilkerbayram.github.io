function y = sfb(lo, hi, H0, H1, p, q, s);
% y = sfb_fft(lo, hi);
% Synthesis filter bank - partially shift-invariant

Flo = fft(lo);
Flo = kron(ones(1,q),Flo);

Fhi = fft(hi);
Fhi = kron(ones(1,s),Fhi);

X0 = Flo.*H0;

N = length(X0)/p;
for n = 1:p-1,
    X0(N+1:2*N) = X0(1:N) + X0(N+1:2*N);
    X0 = X0(N+1:end);
end
y1 = ifft(X0(1:N)/p);

y2 = ifft(Fhi.*H1);

y = y1 + y2;