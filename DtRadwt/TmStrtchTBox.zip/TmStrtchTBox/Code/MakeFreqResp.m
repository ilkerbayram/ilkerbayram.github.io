function [H0, H1] = MakeFreqResp(N,p,q,s,relax);
% Make frequency responses
% N : length of the signal
% p,q : rational sampling factor of the lowpass channel
% s : downsampling factor of the highpass channel
%
% x ----- U(p) -- H0 -- D(q)-->
%    |
%     ---------- H1 -- D(s)-->

% MAKE H0
s = s+relax;
N0 = p*N;   % length of H0 needs to be p times length of input signal.
wp = (s-1)*pi/(p*s);
ws = pi/q;
w = 2*pi*(0:N0-1)/N0;

k_pass = (w <= wp);                 % pass-band
k_stop = (w >= ws);                 % stop-band
k_trans = (w >= wp) & (w <= ws);    % transition-band

a = (1-1/s)*pi/p;
b = 1/q - (1 - 1/s)/p;
w_scaled = (w - a)/b;

H0 = zeros(1,N0);
%H0(k_pass) = sqrt(p*q);
%H0(k_trans) = sqrt(p*q) * (1+cos(w_scaled(k_trans))) .* sqrt(2-cos(w_scaled(k_trans)))/2;
H0(k_pass) = 1;
H0(k_trans) = (1+cos(w_scaled(k_trans))) .* sqrt(2-cos(w_scaled(k_trans)))/2;


M = floor(N0/2);   
m = 1:M;
H0(N0-m+1) = H0(1+m);     % from pi to 2pi

% Make H1

H1 = sqrt( 1 - H0.^2  );
H1 = H1(1:N);
M = floor(N/2);
m = 1:M;
H1(N-m+1) = H1(1+m);    % from pi to 2pi

H0 = H0*sqrt(p*q);
%H1 = H1*sqrt(s); %this is the original
H1 = H1*sqrt(s-relax); %comment out this line to go back to the original