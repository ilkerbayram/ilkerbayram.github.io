function [H0, H1] = MakeFreqRespDual(N,p,q,s,relax,tip);
% Make frequency responses
% N : length of the signal
% p,q : rational sampling factor of the lowpass channel
% s : downsampling factor of the highpass channel
%
% x ----- U(p) -- H0 -- D(q)-->
%    |
%     ---------- H1 -- D(s)-->

% MAKE H0
s = s+relax;

N0 = p*N;   % length of H0 needs to be p times length of input signal.
wp = (s-1)*pi/(p*s);
ws = pi/q;
w = 2*pi*(0:N0-1)/N0;
w2 = 2*pi*(0:N-1)/N;


k_pass = (w <= wp);                 % pass-band
k_stop = (w >= ws);                 % stop-band
k_trans = (w >= wp) & (w <= ws);    % transition-band
k_nz = (w <= ws);                   % non-zero band

a = (1-1/s)*pi/p;
b = 1/q - (1 - 1/s)/p;
w_scaled = (w - a)/b;

H0 = zeros(1,N0);
%H0(k_pass) = sqrt(p*q);
%H0(k_trans) = sqrt(p*q) * (1+cos(w_scaled(k_trans))) .* sqrt(2-cos(w_scaled(k_trans)))/2;
H0(k_pass) = 1;
H0(k_trans) = (1+cos(w_scaled(k_trans))) .* sqrt(2-cos(w_scaled(k_trans)))/2;

if (tip == 'd'),
    PhLo = exp(-j*(q-p)*w/2);
    PhHi = exp(j*(w2-pi)/2);
else
    if (tip == 'f'),
        PhLo = exp(-j*q*w/2);
        PhHi = ones(1,N); %to be modified
    else
        PhLo = ones(1,N0);
        PhHi = ones(1,N);
    end
end
H0 = H0.*PhLo;
        


M = floor(N0/2);   
m = 1:M;
H0(N0-m+1) = conj(H0(1+m));     % from pi to 2pi

% Make H1

H1 = sqrt( 1 - abs(H0).^2  );
H1 = H1(1:N);
H1 = H1.*PhHi;
M = floor(N/2);
m = 1:M;
H1(N-m+1) = conj(H1(1+m));    % from pi to 2pi

H0 = H0*sqrt(p*q);
H1 = H1*sqrt(s-relax);

return