function y = IDWT_FFT(w,p,q,s,varargin)
% Inverse DWT using the overcomplete rational FB
% w : coefficients formatted as the output of DWT_FFT
% p,q,r,s : sampling factors for the FB below
%  ----- U(p) -- H0 -- D(q)-->
%    |
%     -- U(r) -- H1 -- D(s)-->
% note : currently only r=1 is supported

r = s;
if nargin > 4,
    r = varargin{1};
end

L = length(w)-1;
lo = w{L+1};
hi = w{L};
N = length(hi)*s;
    
for n = L:-1:1,
    hi = w{n};
    N = length(hi)*s;
    K = N*p/q;
    lo = lo(1:K);
    [H0,H1] = MakeFreqResp(N, p, q, s, r-s);%comment out this line to go back to the original
    lo = sfb(lo, hi, H0, H1, p, q, s);
end
y = lo;