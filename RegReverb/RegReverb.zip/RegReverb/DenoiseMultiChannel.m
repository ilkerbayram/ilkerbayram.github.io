function [X] = DenoiseMultiChannel(Y,K,Gs,lambda,MAX_ITER)
% denoising multichannel STFT coefficients via singular value clipping
% 
%%% Input Variables %%%
%
% Y : noisy multichannel data
% K : the parameter that determines the 'S' operator as in the manuscript
% Gs : group-size
% lambda : weight of the regularization term
% MAX_ITER : number of iterations
%
%%% Output Variable %%%
% 
% X : denoised multichannel STFT coefficients
%
%
% Ilker Bayram
% ibayram@itu.edu.tr
% Istanbul Technical University, 2016

clip = @(x,tau) x ./ max( abs(x), 1); 

alp = 1.9 / (lambda^2 * (2*K+1));

% initialization
Z = RealizeS(Y,K);
Z = zeros(size(Z));

wb = waitbar(0,'Denoising Multichannel Data');

for iter = 1:MAX_ITER,
    waitbar(iter/MAX_ITER,wb);
    
    % the forward step
    Z = Z - alp * lambda * RealizeS( lambda * RealizeSt(Z,K) - Y, K );
    
    % the backward step - Singular Value Thresholding
    
    for k = 1:Gs:size(Z,1),
        k1 = min(k + Gs - 1, size(Z,1));
        A = Z(k:k1,:);
        [U1,S1,V1] = svd(A,'econ');
        S1 = clip(S1);
        Z(k:k1,:) = U1 * S1 * V1';       
    end    
    
end
close(wb);

X = Y - lambda * RealizeSt(Z,K);
 
    
%%% auxiliary functions

function [X] = RealizeS(Y,K)

% initialization
M = size(Y,2);
X = zeros(size(Y,1), M * (2*K+1));
cnt = 0;
X(:,(cnt+1):cnt+M) = Y;

for k = 1:K,
    cnt = cnt + M;
    X(1:end-k,(cnt+1):cnt+M) = Y(k+1:end,:);
    cnt = cnt + M;
    X(k+1:end,(cnt+1):cnt+M) = Y(1:end-k,:);
end


function [X] = RealizeSt(Z,K)

% initialization
M = size(Z,2) / (2*K+1);
X = Z(:,1:M);

cnt = 0;
for k = 1:K,
    cnt = cnt + M;
    X(k+1:end,:) = X(k+1:end,:) + Z(1:end-k,(cnt+1):cnt+M);
    cnt = cnt + M;
    X(1:end-k,:) = X(1:end-k,:) + Z(k+1:end,(cnt+1):cnt+M);
end