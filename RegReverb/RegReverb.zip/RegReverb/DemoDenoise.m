% Matlab code for one of the experiments from the manuscript 'Regularizing
% Reverberant Multichannel Audio'.
%
% Ilker Bayram
% ibayram@itu.edu.tr
% Istanbul Technical University, 2016

clear all;
close all;

% First, load the clean observation and the noise STFT coefficients for the
% frequency band correspondint to 650 Hz. This is the data used for the
% experiments in the manuscript.

load DataSingleBand; 
% Two variables, namely 'clean' and 'noise' are loaded.
% Both are multichannel complex valued data and are normalized to have unit energy.
N = size(clean,1); % this is the number of STFT coefficients in a band as in the manuscript.
M = size(clean,2); % this is the number of microphones as in the manuscript

% set the group size
Gs = 100;

% Set the SNR
% This variable can be varied -- the rest of the code adapts to this
% variable.
SNR = 5;

% produce observations with the given SNR
en = 10^(-SNR/10); % energy of the noise
sig = sqrt(en / (N * M)); % the sigma value for the 'ideal' threshold
obs = clean + sqrt(en) * noise;

%check the SNR
SNR_observed = snr(clean,obs-clean)

% the parameter K that determines the 'S' operator
K = 7;

% the estimate of a reasonable lambda given in the manuscript
lambda = sig * sqrt(Gs / (2*K+1));

% maximum number of iterations
MAX_ITER = 50; 
lambdalist = lambda * (1.1).^(-20:0);
SNRlist = SNR * ones(size(lambdalist));

% initialize
bestSNR = SNR;
bestEst = obs;

cnt = 0;
for lam = lambdalist,
    cnt = cnt + 1;
    
    rec = DenoiseMultiChannel(obs,K,Gs,lam,MAX_ITER);
    
    % record the SNR and update the best estimate if necessary
    SNRlist(cnt) = snr(clean,clean - rec);
    if SNRlist(cnt) > bestSNR,
        bestSNR = SNRlist(cnt);
        bestEst = rec;
    end
end

%% display results

% plot the SNR curve with respect to lambda
figure;
plot(lambdalist,SNRlist);
axis tight;
xlabel('\lambda');
ylabel('Output SNR (dB)');
title(strcat('Input SNR = ',num2str(SNR),' dB'));

% plot the best estimate for channel 'c'
c = 2;

figure;
subplot(3,1,1);
plot(real(clean(:,c)));
title('Clean signal');

subplot(3,1,2);
plot(real(obs(:,c)));
title('Observed signal');

subplot(3,1,3);
plot(real(bestEst(:,c)));
title('Reconstructed signal');