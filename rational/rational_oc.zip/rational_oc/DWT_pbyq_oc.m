function [coef] = DWT_pbyq_oc(x,h,p,q,max_lev)
%overcomplete rational DWT
%x : signal
%h : cell array holding the filters, h{1} is the lowpass filter
%p, q : rational FB parameters
%max_lev : the number of stages
a=x;
for n = 1:max_lev,
    c = analysis_pbyq_tight(a,h,p,q);
    for k=1:q,
        coef{n,k+1} = c{k+1};
    end
    a = c{1};
end
coef{max_lev,1} = c{1};

function [c] = analysis_pbyq_tight(x,h,p,q);
%nonperiodic analysis fb for the tight frame
%h is a cell array holding the filters, h{1} is the lowpass filter

c{1} = upfirdn(x,h{1},p,q);

for n=2:q+1,
    c{n} = upfirdn(x,h{n},1,q);
end