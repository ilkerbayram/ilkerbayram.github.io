function [y] = IDWT_pbyq_oc(coef,g,p,q)
%coef : coefficient cell array from DWT_pbyq_oc
%g : cell array holding the synthesis filters, g{1} is the lowpass filter
%p, q : rational FB parameters

max_lev = size(coef,1);

a{1} = coef{max_lev,1};
for n = max_lev:-1:1,
    for k = 2:q+1,
        a{k} = coef{n,k};
    end
    c = synthesis_pbyq_tight(a,g,p,q);
    a{1} = c;
end
y = a{1};


function [x]=synthesis_pbyq_tight(c,g,p,q);
%nonperiodic synthesis fb for the tight frame
%c is formatted as the output of analysis counterpart
%g is a cell array holding the synthesis filters, g{1} is the lowpass
%filter

%filter lengths
for n = 1:length(g),
    flen(n) = length(g{n});
end

y{1} = upfirdn(c{1},g{1},q,1);
y{1}=y{1}(flen(1):end);
y{1}=y{1}(1:p:end);

for n = 2:q+1,
    y{n} = upfirdn(c{n},g{n},q,1);
    y{n}=y{n}(flen(n):end);
end

len = [];
for n = 1:length(g),
    len = [len length(y{n})];
end

M = max(len);
for n = 1:q+1,
    y{n} = [y{n} zeros(1, M - length(y{n}))];
end

x = zeros(1,M);
for n = 1:q+1,
    x = x+y{n};
end