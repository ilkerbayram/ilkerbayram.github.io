% Matlab code for Experiment-1 in the manuscript
% 'The Douglas-Rachford Algorithm for Weakly Convex Penalties', Ilker Bayram, Ivan W. Selesnick, 2015.

clear all;
close all;
          
% the cost function
Cost = @(y,H,tau,a,x)  0.5 * sum( (y - H*x).^2 ) + sum( (tau*abs(x) - a*(x.^2)/2).*(abs(x) < tau/a) + (1/(2*a))*tau^2*(abs(x)>= (tau/a))  );

% the threshold function
Th = @(x,alp,tau,a) [abs(x) > (alp*tau)].*[abs(x) < (tau/a)].*sign(x).*[(abs(x) - alp*tau)/(1-alp*a)] + [abs(x) >= tau/a].*x;

%%% the operators used in the algorithms
% ( 2*J_g - I )
Ng = @(x,alp,tau,a) ( 2*Th(x,alp,tau,a) - x);

% ( 2 * J_f - I )
Nf = @(x,H,G,alp,y) 2 * G * ( x + alp * H' * y ) - x;

% ( 2*K_1 - I )
Kg = @(x,alp,rho,tau,a) 2 * Th( x / ( 1 + alp * rho ), alp / (1 + alp * rho ), tau, a ) - x;

% ( 2 * K_2 - I )
Kf = @(x,H,G,alp,rho,y) 2 * G * ( x / ( 1 - alp * rho ) + ( alp / ( 1 - alp * rho ) ) * H' * y ) - x;

%%% produce data
K = 90; % length of the clean signal
x = (rand(K,1) < 0.2) .* randn(K,1); % the underlying sparse signal

% construct the convolution matrix H
H = convmtx([0.3 1 0.3], K+30);
H = H(:,3:K+2);

E = eig(H'*H);
max(E) / min(E)
% produce the observations

SNR = 10;
y = H*x;
en = sum(y.^2) / 10^(SNR/10);
sig = sqrt(en / length(y) );
y = y + sig*randn(size(y));


% parameters of the penalty function
rho = min(E); 
tau = rho*sig*3; % we select the deadzone by taking into account the amount of noise

alpSD = 1/max(E); % alpha that guarantees strict descent for ISTA
alpMax = 2/(max(E) + rho); % maximum value of alpha for ISTA

alpDR = 0.99/sqrt(max(E) * min(E)); % this is the maximum possible alpha from Proposition - 1 

alpDR2 = 0.99 / rho; % maximum value of alpha from Proposition - 2


G = inv( eye(size(H,2)) + alpDR * H' * H ); % the inverse matrix used in the first algorithm

G2 = inv( eye(size(H,2)) + alpDR2 * H' * H / (1 - alpDR2 * rho )); % the inverse matrix used in the second algorithm

% obtain the limit for distance calculation with ISTA
init = zeros(size(x));
zDR1 = init;
alp = alpMax;
alpSD = alpMax;
MAX_ITER = 20000;
for iter = 1:MAX_ITER,   
    zDR1 = Th(zDR1 + alpSD*H'*(y - H*zDR1),alpSD,tau,rho);    
end
zlim = zDR1; % zlim holds the limit referred to as x* in the manuscript

% variables used in ISTA, and the two DR algorithms

zDR1 = init;
z0 = zDR1;
zDR2 = zDR1;
z2 = zDR1; 
z1 = zDR1;
zISTA = zDR1;

z3 = zDR1;
z4 = zDR1;
z5 = zDR1;

MAX_ITER = 200;
costlist = zeros(1,MAX_ITER); % for ISTA with alpha0
costlist2 = costlist;
costlist3 = costlist;

dist = zeros(1,MAX_ITER); % for ISTA with alpha0
dist2 = dist;
dist3 = dist;
for iter = 1:MAX_ITER,
    % the algorithm from Prop - 1 
    costlist(iter) = Cost(y,H,tau,rho,zDR1);
    dist(iter) = sum((zDR1-zlim).^2);
    z1 = Ng(z0,alpDR,tau,rho);    
    z2 = Nf(z1,H,G,alpDR,y);
    z0 = 0.5 * ( z0 + z2 );
    zDR1 = Th(z0,alpDR,tau,rho); % normally we compute this only at the last iteration
        
   
     % the algorithm from Prop - 2
     costlist3(iter) = Cost(y,H,tau,rho,zDR2);
     dist3(iter) = sum((zDR2-zlim).^2);
     z4 = Kg( z3, alpDR2, rho, tau, rho );
     z5 = Kf( z4, H, G2, alpDR2, rho, y );     
     z3 = 0.5 * ( z3 + z5 );
     zDR2 = Th( z3 / ( 1 + alpDR2 * rho ), alpDR2 / (1 + alpDR2 * rho), tau, rho); % normally we compute this only at the last iteration
    
    
    % ISTA with alphaMax
    costlist2(iter) = Cost(y,H,tau,rho,zISTA);
    dist2(iter) = sum((zISTA-zlim).^2);
    zISTA = Th(zISTA + alpMax*H'*(y - H*zISTA),alpMax,tau,rho);    
end

% the rest are figures...

MS = 14;
MS2 = 8;

LW1 = 1;
LW2 = 2.5;

figure;
subplot(2,1,1);
plot(zDR1,'o','MarkerSize',MS2);hold on;stem(x,'.','MarkerSize',MS);
axis tight;
legend('Estimated','True','Location','SouthEast');
title('Reconstruction');

ind = 1:20;
figure;
subplot(2,1,1);
plot(log(costlist(ind)),'LineWidth',LW2);
hold on;
plot(log(costlist3(ind)),'--','LineWidth',LW1);
plot(log(costlist2(ind)),':','LineWidth',LW2);
legend('Prop. 2','Prop. 3','ISTA');
axis tight;
xlabel('Iterations');
ylabel('log(cost)');
title('History of the Cost');


subplot(2,1,2);
plot(log(dist),'LineWidth',LW2);
hold on;
plot(log(dist3),'--','LineWidth',LW1);
plot(log(dist2),':','LineWidth',LW2);
axis tight;
legend('Prop. 2','Prop. 3','ISTA','Location','SouthWest');
xlabel('Iterations');
ylabel('log( || x - x* ||_2 )');
title('History of the Distance to the Limit');