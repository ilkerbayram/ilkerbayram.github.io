This folder contains Matlab code for the experiments from 'The Douglas-Rachford Algorithm for Weakly Convex Penalties', by I. Bayram, I. W. Selesnick, 2015.
The figures for Experiment-1 and Experiment-2 can be produced by running Experiment1.m and Experiment2.m respectively. Please notice that the data is produced randomly and the produced figures may be different than the ones in the manuscript.

Ilker Bayram
ibayram@itu.edu.tr
Istanbul Technical University, 2015.