function [x] = Algorithm2(y,h,tau,Nx,MAX_ITER)
% This is an implementation of Algorithm-2 from the manuscript,
% 'Proximal Mappings with Almost Structured Matrices', 
% by I. Bayram, 2015.
%
% Code written by I. Bayram,
% ibayram@itu.edu.tr,
% Istanbul Technical University, 2015

soft = @(x,tau) x .* max( abs(x) - tau,0) ./ ( abs(x) + 10^(-10) ); 

lam = 0.1; % lambda in the manuscript

m = length(y);
mp = length(h) + Nx - 1;
Q = 128;
mp = Q * ceil( mp / Q);

% initialization;

u = zeros(mp,1);
ut = zeros(mp,1);
t = zeros(mp,1);
tt = zeros(mp,1);

t(1:m) = y;

H = fft(h,mp);
H = H.';

alp = 0.1; % alpha in the manuscript

bet = alp/(1+alp); % beta in the manuscript

invH = 1./(1 + bet * abs(H).^2); % inverse in the FFT domain



wb = waitbar(0,'Algorithm-2 running');
for iter = 1 : MAX_ITER,
    waitbar(iter/MAX_ITER,wb);
    %
    % update u
    T = fft(t);
    T = invH .* ( fft(u) + bet * conj(H) .* T );
    ut = ifft(T);
    
    % update ttilde
    tt = (1-alp) * t / (1+alp) + 2 * bet * ifft( H .* T);
        
    % update xtilde
    u(1:Nx) = u(1:Nx) + 2 * (1-lam) * ( soft( 2*ut(1:Nx) - u(1:Nx), alp * tau ) - ut(1:Nx) );
    
    % update ztilde
    u( Nx+1 : end ) = u( Nx+1 : end ) - 2 * (1-lam) * ut( Nx+1 : end) ;
    
    % update t
    t(1:m) = lam * t(1:m) + (1-lam) * ( 2 * y - tt(1:m) );
    t(m+1:end) = lam * t(m+1:end) + (1-lam) * tt(m+1:end);    
    
end
close(wb);
% the final proximal
T = fft(t);
T = invH .* ( fft(u) + bet * conj(H) .* T );
ut = ifft(T);
x = ut(1:Nx);
    