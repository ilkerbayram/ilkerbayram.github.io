This folder contains Matlab code for the algorithms discussed in 'Proximal Mappings with Almost Structured Matrices', by I. Bayram.

The main file is Demo.m, which produces data for a problem, calls the two algorithms (Alg-1 with PCG, Alg-2 described in the manuscript) and compares their running time, final cost values and shows the optimality plots.