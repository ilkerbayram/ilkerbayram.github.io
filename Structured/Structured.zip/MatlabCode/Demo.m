clear all;
close all;

Nx = 100000;

%% producing the observations

% desired signal
x = randn(1,Nx);
x = x .* ( rand(1,length(x)) > 0.95 );

% blurring filter
h = rand(1,2000);
t = 1 * (1:length(h))/length(h);
mask = exp(-7*t);
h = h.*mask;

figure;plot(h);axis tight;title('Blurring Filter');

% blurred signal
y = conv(x,h);
SNR = 10;
en = sum(abs(y).^2) / 10^(SNR/10);
sig = sqrt(en/length(y));
y = y + sig * randn(size(y)); % noisy observations
y = y(1:length(x));
tau = sig*3; % tau value weighting the l1 term

%% computing the solutions

% Algorithm - 1
MAX_ITER = 20;
tic
x1 = Algorithm1(y',h,tau,length(x),MAX_ITER);
tAlg1 = toc

% Algorithm - 2
MAX_ITER = 400;
tic
x2 = Algorithm2(y',h,tau,length(x),MAX_ITER);
tAlg2 = toc

%% final cost values

% Algorithm - 1
xhat = x1;
z = conv(xhat,h);
costAlg1 = 0.5 * sum( ( z(1:length(y)) - y').^2) + tau * sum(abs(xhat))


% Algorithm - 2
xhat = x2;
z = conv(xhat,h);
costAlg2 = 0.5 * sum( ( z(1:length(y)) - y').^2) + tau * sum(abs(xhat))



%% optimality plots

figure;
P = 100; % sampling period

% Algorithm - 1
subplot(2,1,1);
xhat = x1;
z = conv(h,xhat);z = z(1:end - length(h) + 1);
z = conv(h(end:-1:1),y' - z);
z = z(length(h):end);
plot(xhat(1:P:end),z(1:P:end),'.');
set(gca,'YTick',tau*[-1 1]);
grid on;
title('Optimality Plot (Algorithm - 1)');


% Algorithm - 2
subplot(2,1,2);
xhat = x2;
z = conv(h,xhat);z = z(1:end - length(h) + 1);
z = conv(h(end:-1:1),y' - z);
z = z(length(h):end);
plot(xhat(1:P:end),z(1:P:end),'.');
set(gca,'YTick',tau*[-1 1]);
grid on;
title('Optimality Plot (Algorithm - 2)');