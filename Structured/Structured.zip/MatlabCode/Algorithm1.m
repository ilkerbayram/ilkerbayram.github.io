function [x] = Algorithm1(y,h,tau,Nx,MAX_ITER,varargin)
% solves
% min_x 0.5 || y - H x ||_2^2 + tau * || x ||_1
% where H is a Toeplitz matrix derived from the causal filter h of size length(y) by Nx, using
% the Douglas-Rachford algorithm as described in 
% 'Proximal Mappings with Almost Structured Matrices',
% Ilker Bayram, 2015
%
% Code written by Ilker Bayram, 
% ibayram@itu.edu.tr
% Istanbul Technical University, 2015


lam = 0.1;

x = zeros(Nx,1);
y = y(:);

alp = 0.1;
yz = alp * conv(y,h(end:-1:1));
yz = yz(length(h):end);

mul = @(x) ToeplitzMult(h,alp,x); % efficient multiplication with H

precond = @(x) CircInv(h,alp,x); % efficient inverse for the preconditioning matrix

tol = 1e-4; % tolerance for PCG
MAXIT = 100; % maximum number of iterations for the PCG

wb = waitbar(0,'Algorithm-1 running');
for iter = 1 : MAX_ITER,
    waitbar(iter/MAX_ITER,wb);
    %%
    
    xt = pcg(mul, x + yz , tol, MAXIT, precond) * 2 - x;
    
    x = lam * x + (1-lam) * ( [ 2 * xt .* max( abs(xt) - alp * tau, 0) ./ ( abs(xt) + 10^(-20) ) ] - xt );
    
end
close(wb);
% the final prox
 x = pcg(mul , x + yz , tol, MAXIT, precond);
 
%%

function [y] = CircInv(h,alp,x)
% fast implementation for the inverse of the circulant preconditioning matrix
M = 1 + alp * abs(fft(h(:),length(x))).^2;
Y = fft(x) ./ M;
y = real(ifft(Y));

%%
function [y] = ToeplitzMult(h,alp,x)
% fast multiplication with H
y = conv(x,h);
y = y(1:length(x));
y = conv(y,h(end:-1:1));
y = x + alp * y( length(h) : end );
y = y(:);
