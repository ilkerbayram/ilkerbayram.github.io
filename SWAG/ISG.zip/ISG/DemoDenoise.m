% A comparison of soft/hard/Elasso/Proposed threshold
% For a desription of the setup, see Sec. II.D of the manuscript
% 'A Penalty Function Promoting Individual Sparsity in Groups', 
% by I. Bayram and S. Bulek, 2016.

clear all;
close all;

% declaration of soft and hard threshold functions
soft = @(x,tau) max(abs(x) - tau,0) .* sign(x);
hard = @(x,tau) x .* ( abs(x) > tau );


K = 1; % number of non-zeros in each sequence
L = 10; % length of the signals
N = 1000; % number of trials

% the underlying clean signal
x = [randn(K,N); zeros(L-K,N) ]; 

% form the noisy observations for the given input SNR
SNRin = 5;

ex = sum(abs(x(:)).^2);
en = ex / 10^(SNRin/10);
sig = sqrt(en / length(x(:)));        

y = x + sig * randn(size(x)); % the noisy observations

% the parameters for the different threshold functions (manually chosen for input SNR = 5dB)

lamS = 1 * sig; % threshold for the soft treshold
lamH = 3 * sig; % threshold for the hard treshold
lamE = sig / 2; % threshold for Elasso and the proposed method
gam = 0.9 / lamE; % gamma for the proposed method
        

% soft thresholding
zSoft = soft(y,lamS);
SNRsoft = snr(x,zSoft-x)

% hard thresholding
zHard = hard(y,lamH);
SNRhard = snr(x,zHard-x)

% ELasso threshold
zElasso = ELassoThold(y,lamE);
SNRelasso = snr(x,zElasso-x)

% proposed threshold
zProp = nVariateLinear(y,lamE,gam); % realization of the threshold with a linear search for 'k'
SNRprop = snr(x,zProp - x)

% check the consistency of Algorithm-1 and Algorithm-2 in the manuscript
zProp2 = nVariateBinary(y,lamE,gam); % realization of the threshold with a binary search for 'k'
SNRprop2 = snr(x,zProp2 - x)


difference = max( abs( zProp(:) - zProp2(:) ) ) % this should be practically zero