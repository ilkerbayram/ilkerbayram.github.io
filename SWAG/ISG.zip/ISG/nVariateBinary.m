function [x] = nVariateBinary(y,lam,gam)
% The proposed threshold using Algorithm-2 in the manuscript
% 'A Penalty Function Promoting Individual Sparsity in Groups', 
% by I. Bayram and S. Bulek, 2016.
%
% the threshold is applied to each column of y

z = sort(abs(y), 1, 'descend');

h = filter(1, [1 -1], z); % running sum to be used in h
n = size(y,1);
h = lam * ( 1 - lam * gam ) + lam * gam * h;
v = 1 ./ ( 1 + ( 0:(n-1) ) * lam * gam );
h = bsxfun(@times,h,v');
x = zeros(size(y));

for c = 1:size(y,2), % apply to each column individually
    flag = true;
    if z(1,c) < lam,
       Th = lam;
       flag = false;
    elseif z(n,c) > h(n,c),
        Th = h(n,c);
        flag = false;
    else
        k0 = 0;
        k1 = n;
    end
    while flag,
        k = floor((k0 + k1)/2);
        if (z(k,c) > h(k,c)) && (z(k+1,c) <= h(k,c)),
            flag = false;
            Th = h(k,c);
        elseif z(k,c) <= h(k,c),
            k1 = k;
        else
            k0 = k;
        end
        if flag && (k == round((k0 + k1)/2)), % no update -- something's wrong
            disp('something wrong with n-variate');
            flag = 0;
            Th = 0;
        end            
    end
    xx =  max(1 - Th ./ (10^(-10) + abs(y(:,c)) ) , 0);
    xx =  xx .* y(:,c) / (1- lam * gam); 
    x(:,c) = xx;
end