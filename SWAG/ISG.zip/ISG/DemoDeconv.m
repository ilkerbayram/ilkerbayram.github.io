% Main program for the deconvolution simulations in Sec.IV of the manuscript
% 'A Penalty Function Promoting Individual Sparsity in Groups', 
% by I. Bayram and S. Bulek, 2016.
%
% compares three algorithms:
%  - iterative p-shrinkage algorithm (IPS)
%  - proposed n-variate penalty 
%  - sparse Group Lasso (SGL)

clear all;
close all;
clc;

% Change to choose another realization of gaussian noise
seed = 1 ;
randn('state',seed);
rand('state',seed);

%% the wavelet
load('ricker.mat') ;
wL = length(h); % length of the blur function

%% the sparse signal
load('sparse_sig.mat')
xL = length(x);

figure
subplot(212)
plot(x)
title(['Sparse signal with nonzero samples = ' num2str(sum(x~=0))])

subplot(211)
plot(h)
title('Wavelet')

%% produce the noise-free observation
y_noisefree = convH(x,h); % noise-free observations

SNR = 5; % input SNR
sig = sqrt( sum(abs(y_noisefree).^2) / (xL * 10^(SNR/10))); % noise std

MAX_ITER = 2000; % 5K for SNR=5, 10K for SNR=10 & SNR=15, 20K for SNR=20

NTrial = 10; % number of trials

%% Deconvolution with ISTA using the proposed penalty
% parameters
alp = 2 * sum(abs(xcorr(h))); % this is an upper bound for || H' * H ||

lam_nVariate = 2.5 * sig;
gam = 0.9 * min(alp,1) / lam_nVariate ; % this ensures that the denoising step is convex...

Gs = 8;  % group size for the nVariate Threshold -- xL should be divisible by Gs

%% SGL parameters
alpSGL = 0.95; % this should be in the range (0,1)
lamSGL = 2.5 * sig;

%% IPS parameters
p_pShrink = -0.5;
lam_pShrink = 0.21 * sig; % 0.21 for SNR=5, 0.25 for SNR=10 & SNR=15, 0.32 for SNR=20


disp(['SNR = ' num2str(SNR)])
disp(['No of iterations = ' num2str(MAX_ITER)])
disp(['Group size = ' num2str(Gs)])


snr_store = zeros(NTrial, 3); % store steady-state performance value

snr_flag = 1; % store performance evolution

snr_iter_sgl_store = zeros(MAX_ITER, NTrial); % store transient performance values 
snr_iter_pShrink_store = zeros(MAX_ITER, NTrial);
snr_iter_nvt_store = zeros(MAX_ITER, NTrial);

for trial = 1:NTrial,

    noise = randn(1, xL);
    y = y_noisefree + noise * sig; % the noisy observations
    
    [x_sgl, cost_sgl, snr_iter_sgl] = deconv_SGL(y, h, alp, lamSGL, alpSGL, Gs, MAX_ITER, x, snr_flag);
    
    [x_pShrink, snr_iter_pShrink] = deconv_pShrink(y, h, alp, lam_pShrink, p_pShrink, MAX_ITER, x, snr_flag);
    
    [x_nVariate, cost_nVariate, snr_iter_nvt] = deconv_nVariate(y, h, alp, lam_nVariate, gam, Gs, MAX_ITER, x, snr_flag);
    
    % performance measurement
    snr_sgl = snr(x, x - x_sgl);
    snr_pShrink = snr(x, x - x_pShrink);
    snr_nVariate = snr(x, x - x_nVariate);
    
    snr_store(trial,:) = [snr_sgl, snr_nVariate, snr_pShrink];  % store steady-state performance values
    
    snr_iter_sgl_store(:,trial) = snr_iter_sgl;  % store transient performance values
    snr_iter_pShrink_store(:,trial) = snr_iter_pShrink;
    snr_iter_nvt_store(:,trial) = snr_iter_nvt;
    
end

% performance statistics
mean_snr = mean(snr_store,1);
std_snr = std(snr_store,0,1);


mean_snr_iter_sgl = mean(snr_iter_sgl_store,2);
mean_snr_iter_ips = mean(snr_iter_pShrink_store,2);
mean_snr_iter_nvt = mean(snr_iter_nvt_store,2);

std_snr_iter_sgl = std(snr_iter_sgl_store,0,2);
std_snr_iter_ips = std(snr_iter_pShrink_store,0,2);
std_snr_iter_nvt = std(snr_iter_nvt_store,0,2);


figure
hold
p1 = plot(mean_snr_iter_sgl, 'r');
p1b = plot(mean_snr_iter_sgl + 3*std_snr_iter_sgl,'r--');
p1c = plot(mean_snr_iter_sgl - 3*std_snr_iter_sgl,'r--');

p2 = plot(mean_snr_iter_nvt, 'b');
p2b = plot(mean_snr_iter_nvt + 3*std_snr_iter_nvt,'b--');
p2c = plot(mean_snr_iter_nvt - 3*std_snr_iter_nvt,'b--');

p3 = plot(mean_snr_iter_ips, 'g');
p3b = plot(mean_snr_iter_ips + 3*std_snr_iter_ips,'g--');
p3c = plot(mean_snr_iter_ips - 3*std_snr_iter_ips,'g--');


title(['Reliability plots at SNR = ' num2str(SNR) 'dB' ])
xlabel('Iteration index')
ylabel('SRER (dB)')
legend([p1,p2,p3],'SGL','Proposed','IPS')

