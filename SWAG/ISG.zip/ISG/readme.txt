This folder contains Matlab code for some of the experiments from the manuscript 'A Penalty Function Promoting Individual Sparsity in Groups', by I. Bayram and S. Bulek, 2016. The two main scripts are 

1) DemoDenoise.m : contains part of the code used in the experiment in Sec.II.D.

2) DemoDeconv.m : contains part of the code used in the experiment in Sec.IV.B.