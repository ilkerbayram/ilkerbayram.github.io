% Demo file for the experiment showing that the best value of the product
% gamma * lambda is independent of the scale of the observations (fig 5 in the manuscript)

clear all;
close all;

L = 10; % length of the signal
N = 10000; % number of trials

SNRin = 5; % input SNR

siglist = 0.5:0.1:5; %noise std varies in this range
gamlist =  1.05.^(linspace(-100,-1,50)); % gamma varies in this range
for K = 1:2, % K denotes the number of non-zeros in the length-L signal
    SNRs = zeros(length(siglist),length(gamlist));
    r = 0;
    
    for sig = siglist,
        
        r = r+1;
        
        lam =  0.5 * sig; % lambda is always set to 0.5 * (noise std)
        
        x = [randn(K,N); zeros(L-K,N) ]; % produce the sparse signal with K non-zeros 
        
        % adjust the scale of the clean signal so that the SNR is constant
        n = sig * randn(size(x));
        ex = sum(abs(x(:)).^2);
        en = sum(abs(n(:)).^2);
        ex2 = en * 10^(SNRin/10);
        x = x *sqrt(ex2/ex);
        
        y = x + n; % the noisy observation
        
        c = 0;
        for gam = (1/lam) * gamlist,
            c = c + 1;
            
            z = TholdProposedLinear(y,lam,gam); % estimate using the proposed threshold
            
            SNRs(r,c) = (snr(x,z-x) - SNRin);
        end
        
    end
    SNRlist{K} = SNRs;
    [v,ind] = max(SNRs,[],2);
    best = zeros(1,length(siglist));
    for r = 1:length(siglist),
        best(r) = gamlist(ind(r));
    end
    gambest{K} = best;
end

%%

figure;
pt = SNRlist{1}';
pt = pt(end:-1:1,:);
subplot(2,2,1);
imagesc(siglist,gamlist(end:-1:1),pt);
colorbar;
xlabel('\sigma');
ylabel('\lambda \gamma');

figure;
pt = SNRlist{2}';
pt = pt(end:-1:1,:);
subplot(2,2,1);
imagesc(siglist,gamlist(end:-1:1),pt);
colorbar;
xlabel('\sigma');
ylabel('\lambda \gamma');