This folder contains Matlab codes for the the experiments from the manuscript 'A Penalty Function Promoting Sparsity Within and Across Groups', by I. Bayram and S. Bulek, 2016. 

There are three different experiments and the code for each is provided in a separate folder.

1) Experiments from Sec. II.C are in the folder 'Parameter Tuning'. Here, code for producing figures 4 and 5 are provided.

2) Audio Denoising Experiment : The main file is 'DemoDenoise.m' in the folder 'Denoising'

2) Deconvolution Experiment : The main file is 'DemoDeconv.m' in the folder 'Deconvolution'