% Ilker Bayram
% ibayram@itu.edu.tr
% Istanbul Teknik Universitesi, 2012

clear all;
close all;

[y,fs,nbits] = wavread('NeyDarbuka.wav');

% parameters for the transient component
%%% STFT parameters
N = 512;
Hop = 128;
win = bartlett(N);
win = NormalizeW(win,Hop);
param1.win = win;
param1.Hop = Hop;
%%% neighborhood parameters
param1.W = 15;
param1.L = 3;
param1.lam = 0.006;

% parameters for the transient component
%%% STFT parameters
N = 1024;
Hop = 256;
win = hamming(N);
win = NormalizeW(win,Hop);
param2.win = win;
param2.Hop = Hop;
%%% neighborhood parameters
param2.W = 3;
param2.L = 15;
param2.lam = 0.006;

gam = 50;

MAX_ITER = 100;

tic
[x1,x2] = PDHeuristic(y,param1,param2,gam,MAX_ITER);
toc

N = 2048;
Hop = 256;
win = bartlett(N);
win = NormalizeW(win,Hop);

w0 = STFT(y,win,Hop);
w1 = STFT(x1,win,Hop);
w2 = STFT(x2,win,Hop);
w3 = STFT(y - x1 - x2,win,Hop);
e0 = sum(y.^2);
e1 = sum(x1.^2);
e2 = sum(x2.^2);
e3 = sum((y-x1-x2).^2);

Norm = max(abs(w0(:)));
w0 = w0/Norm;
w1 = w1/Norm;
w2 = w2/Norm;
w3 = w3/Norm;

clim = [-75 0];
Fr = [0 5000];

close all;

figure;
DispSTFTWeb(w0, fs, N, Hop, Fr, clim);
title(strcat('Original, Energy = ',num2str(e0)));

figure;
DispSTFTWeb(w1, fs, N, Hop, Fr, clim);
title(strcat('Transient, Energy = ',num2str(e1)));

figure;
DispSTFTWeb(w2, fs, N, Hop, Fr, clim);
title(strcat('Tonal, Energy = ',num2str(e2)));

figure;
DispSTFTWeb(w3, fs, N, Hop, Fr, clim);
title(strcat('Residue, Energy = ',num2str(e3)));

N1 = 35500;
N2 = 37500;
yp = y(N1:N2);
x1p = x1(N1:N2);
x2p = x2(N1:N2);
figure;subplot(3,1,1);plot(N1:N2,yp,'LineWidth',1.1);hold on;plot(N1:N2,yp-x1p-x2p);axis tight;
xlabel('Time (samples)');

subplot(3,1,2);plot(N1:N2,x1p,'LineWidth',1.1);axis tight;
xlabel('Time (samples)');

subplot(3,1,3);plot(N1:N2,x2p,'LineWidth',1.1);axis tight;
xlabel('Time (samples)');