function DispSTFTWeb(c, fs, N, Hop, F, clim)
% Display the short-time Fourier transform coefficients c
%
% this file is modified from 'displaySTFT.m' originally by 
% I. W. Selesnick, Polytechnic Inst. of NYU
%
% INPUT
%   c: STFT coefficients (2D array)
%   fs: sampling rate
%   N: length of FFT
%   Hop: Hop-size
%   F: display frequency range (in Hz)
%   clim: for 'Clim' of gca
%
% Ilker Bayram, Istanbul Technical University, 2012.


Fd = 1+round(F*N/fs);  

cmap = colormap('jet');
%cmap = cmap(end:-1:1,:);


cdb = 20 * log10( abs( c(Fd(1):1:Fd(2),:) ) );

imagesc([0 size(c,2)*Hop/fs],F/1000,cdb);

set(gca,'Clim',clim);
colormap(cmap);

axis xy;
xlabel( 'Time (seconds)' )
ylabel( 'Frequency (kHz)' )

CB = colorbar;
%set(CB, 'ytick', clim(1):5:clim(2));

shg