function [x1,x2] = PDHeuristic(y,param1,param2,gam,varargin)
% An Heuristic Algorithm for component separation
% uses windowed l2 norms -- see the manuscript for details
%
% Ilker Bayram
% ibayram@itu.edu.tr
% Istanbul Teknik Universitesi, 2012



win1 = param1.win;
Hop1 = param1.Hop;
N1 = length(win1);
lam1 = param1.lam;
W1 = param1.W;
L1 = param1.L;



win2 = param2.win;
Hop2 = param2.Hop;
N2 = length(win2);
lam2 = param2.lam;
W2 = param2.W;
L2 = param2.L;




MAX_ITER = 100;
if ~isempty(varargin),
    MAX_ITER = varargin{1};
end



% initialize
z = STFT(0*y,win1,Hop1);

t = STFT(0*y,win2,Hop2);

sd1 = size(z);

sd2 = size(t);

x1 = zeros(size(y));
x2 = zeros(size(y));
xx1 = x1;
xx2 = x2;
teta = 0.5;

wb = waitbar(0);
figure;
dif = zeros(1,MAX_ITER); % to monitor convergence
for iter = 1:MAX_ITER,
    waitbar(iter/MAX_ITER,wb,strcat(num2str(round(100*iter/MAX_ITER)),'%'));    

    % primal step
    
    v1 = ISTFT(z,win1,Hop1);    
    v1 = real(v1(1:length(y)));
    
    v2 = ISTFT(t,win2,Hop2);
    v2 = real(v2(1:length(y)));
    
    u1 = x1 + gam*(y - lam1*v1);
    u2 = x2 + gam*(y - lam2*v2);
          
    x1 = ((gam + 1)*u1 - gam*u2)/(2*gam + 1);    
    x2 = ((gam + 1)*u2 - gam*u1)/(2*gam + 1);
    
    dif(iter) = sum(abs(xx1 - x1)) + sum(abs(xx2-x2)); % to monitor convergence
    % dual step        
    w = STFT(x1 + teta*(x1 - xx1),win1,Hop1);
    xx1 = x1;
    subplot(1,2,1);imagesc(-(abs(w(end/2:-1:1,:))).^(1/4));colormap(gray);drawnow;
    
    u = z + lam1*gam*w;
    fil = bartlett(W1+2)*bartlett(L1+2)';
    fil = fil(2:end-1,2:end-1);
    fil = fil/sum(fil(:));
    fil = fil/max(fil(:));
      
    v = conv2(abs(u),fil,'same');    
    v = min(1./v,1);
    z = u.*v;        
        
    
    w = STFT(x2 + teta*(x2 - xx2),win2,Hop2);
    xx2 = x2;
    subplot(1,2,2);imagesc(-(abs(w(end/2:-1:1,:))).^(1/4));colormap(gray);drawnow;
    
    u = t + lam2*gam*w;
    fil = bartlett(W2+2)*bartlett(L2+2)';
    fil = fil(2:end-1,2:end-1);
    fil = fil/sum(fil(:));
    fil = fil/max(fil(:));
      
    v = conv2(abs(u),fil,'same');    
    v = min(1./v,1);
    t = u.*v;        
    
    
end
close(wb);
figure;plot(log(dif));