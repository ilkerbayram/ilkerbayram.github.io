% Ilker Bayram
% ibayram@itu.edu.tr
% Istanbul Teknik Universitesi, 2012

clear all;
close all;

[y,fs,nbits] = wavread('NeyDarbuka.wav');

% parameters for the transient component
%%% STFT parameters
N = 512;
Hop = 128;
win = bartlett(N);
win = NormalizeW(win,Hop);
param1.win = win;
param1.Hop = Hop;
%%% mixed norm parameters
param1.W = 16;
param1.L = 2;
param1.SW = 4;
param1.SL = 2;
param1.lam = 0.006;

% parameters for the tonal component
%%% STFT parameters
N = 1024;
Hop = 256;
win = hamming(N);
win = NormalizeW(win,Hop); % the actual window used (a Parseval frame)
param2.win = win;
param2.Hop = Hop;
%%% mixed norm parameters
param2.W = 2;
param2.L = 16;
param2.SW = 2;
param2.SL = 4;
param2.lam = 0.005;

% specify gamma
g1 = param1.lam*ceil(param1.W*param1.L/(param1.SW*param1.SL));
g2 = param2.lam*ceil(param2.W*param2.L/(param2.SW*param2.SL));
gam = min(1/g1,1/g2);

MAX_ITER = 100;

tic
[w1,w2] = PDSynthesis(y,param1,param2,gam,MAX_ITER);
toc

x1 = ISTFT(w1,param1.win,param1.Hop);x1 = real(x1(1:length(y)));
x2 = ISTFT(w2,param2.win,param2.Hop);x2 = real(x2(1:length(y)));

N = 2048;
Hop = 256;
win = bartlett(N);
win = NormalizeW(win,Hop);

w0 = STFT(y,win,Hop);
ww1 = STFT(x1,win,Hop);
ww2 = STFT(x2,win,Hop);
w3 = STFT(y - x1 - x2,win,Hop);
e0 = sum(y.^2);
e1 = sum(x1.^2);
e2 = sum(x2.^2);
e3 = sum((y-x1-x2).^2);

Norm = max(abs(w0(:)));
w0 = w0/Norm;
ww1 = ww1/Norm;
ww2 = ww2/Norm;
w3 = w3/Norm;

clim = [-75 0];
Fr = [0 5000];

close all;

figure;
DispSTFTWeb(w0, fs, N, Hop, Fr, clim);
title(strcat('Original, Energy = ',num2str(e0)));

figure;
DispSTFTWeb(ww1, fs, N, Hop, Fr, clim);
title(strcat('Transient, Energy = ',num2str(e1)));

figure;
DispSTFTWeb(ww2, fs, N, Hop, Fr, clim);
title(strcat('Tonal, Energy = ',num2str(e2)));

figure;
DispSTFTWeb(w3, fs, N, Hop, Fr, clim);
title(strcat('Residue, Energy = ',num2str(e3)));

N1 = 35500;
N2 = 37500;
yp = y(N1:N2);
x1p = x1(N1:N2);
x2p = x2(N1:N2);
figure;subplot(3,1,1);plot(N1:N2,yp,'LineWidth',1.1);hold on;plot(N1:N2,yp-x1p-x2p);axis tight;
xlabel('Time (samples)');

subplot(3,1,2);plot(N1:N2,x1p,'LineWidth',1.1);axis tight;
xlabel('Time (samples)');

subplot(3,1,3);plot(N1:N2,x2p,'LineWidth',1.1);axis tight;
xlabel('Time (samples)');