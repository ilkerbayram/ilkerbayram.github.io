% Demonstration of denoising with the Directional TV, 
% See the manuscript 'Directional Total Variation', 
% Ilker Bayram and Mustafa Kamasak, submitted to IEEE SPL, March, 2012.
% web.itu.edu.tr/ibayram/DTV

clear all;
close all;

% construct the noisy observation
im = imread('1.3.09Samp.tif');
im = double(im); im = im/max(im(:));
sig = 0.2;
x = im + sig*randn(size(im)); % noisy observation

lam = 0.08; %weight of the TV term in the cost function (see eq(7) in the manuscript)
alp = 5; % length of the major axis of the ellipse (minor axis is unit-length)
theta = pi/2; % the direction of the ellipse
MAX_ITER = 150; % number of iterations 

[yTV] = DirectionalDenoise(x,2*lam,1,theta,MAX_ITER); % denoising with TV (notice the difference in lambda)
[yDTV] = DirectionalDenoise(x,lam,alp,theta,MAX_ITER); % denoising with the directional TV

% note  : lambda's are not optimized...

difTV = yTV - im;
difDTV = yDTV - im;
RMSE_TV = sqrt(mean(abs(difTV(:)).^2))
RMSE_DTV = sqrt(mean(abs(difDTV(:)).^2))
figure;imagesc(x);colormap(gray);axis image; title(strcat('\sigma = ', num2str(sig)));
figure;imagesc(yTV);colormap(gray);axis image;title(strcat('TV Denoised,', ' RMSE = ',num2str(RMSE_TV)));
figure;imagesc(yDTV);colormap(gray);axis image;title(strcat('\alpha = ', num2str(alp), ', RMSE = ',num2str(RMSE_DTV)));