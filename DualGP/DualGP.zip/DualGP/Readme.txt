The subfolder '/code' contains python code associated with the manuscript titled 'An Exploratory Method for Smooth/Transient Decomposition'. All of the figures in the manuscript can be produced using this code.

The two scripts to run are :
- Demo_Introduction : reproduces the example in the Introduction.
- Demo_Experiment : reproduces the experiment in Section IV.

The versions of python and the packages I used :
Python version : 3.7.1
Numpy version : 1.15.4
Matplotlib version : 3.0.2

ilker bayram, ibayram@ieee.org, 2019.