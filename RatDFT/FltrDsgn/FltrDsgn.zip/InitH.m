function [h] = InitH(p,q,vm)
%initial filter for sampling factors {p,q}
%number of vanishing moments vm

fac=conv(ones(1,p)/p,ones(1,q)/q);
c=1;
for n=1:vm,
    c=conv(c,fac);
end
c = sqrt(p)*c/sum(c);
N = length(c);


h = mpoly(0,0);
q(1,1,1:N) = c;
h.coef = q;

if mod(N,2) == 1,
    %type I filter
    K = (N-1)/2;
else
    %type II filter
    K = N/2-1;
end

h.min = -K;