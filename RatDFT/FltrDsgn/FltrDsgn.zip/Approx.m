function [AppH] = Approx(h,p,q,vm,N)
%N : length of approximation
%vm : %number of vanishing moments
%h : filter as an mpoly object

B(1:h.length) = h.coef(1,1,1:end);
B = B';

%get the window with the highest energy
en = 0;
for n = 1:length(B)-N+1,
    w = B(n:n+N-1);
    cen = sum(w.^2);
    if cen > en,
        en = cen;
        A = w;
    end
end

fac = conv(ones(1,p)/p,ones(1,q)/q);
f=1;
for n=1:vm,
    f=conv(f,fac);
end

len_x = N-length(f)+1;
V = convmtx(f',len_x);

X = V\A;
APP = V*X;
co(1,1,1:length(APP)) = APP(1:end);

K = floor(N/2);
AppH = mpoly(0,0);
AppH.coef = co;
AppH.min = -K;