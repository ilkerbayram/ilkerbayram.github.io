function [A,B] = FrmBnds(S,no_pts)
%determine the frame bounds 
%given the frame operator representation S
%no_pts : the number of evaluation points on the unit circle

n=1;
for w=0:1/no_pts:1,
    M = S(exp(j*pi*w));
    e=real(eig(M));
    small_eig(n)=min(e);
    big_eig(n)=max(e);
    n=n+1;
end
B = max(big_eig);
A = min(small_eig);