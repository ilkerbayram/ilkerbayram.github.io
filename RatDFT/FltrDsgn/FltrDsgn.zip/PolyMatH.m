function [S,T] = PolyMatH(h,p,q)
%polyphase matrix for the DFT-M FB derived from h,
%and the frame operator
%given sampling factors {p,q}
%S : frame operator
%T : analysis operator
%H(z) = \sum_{k=0}^{p-1} z^(-qk) H_k(z^p)
hp = PolyH(h,p,q);
W = exp(j*2*pi/q);
ind = hp.min:hp.max;
T = hp;
for n =1:q-1;
    A = W.^(ind*n);
    WM = ones(p,1)*A;
    WE(1,1:p,1:hp.length) = WM(1:p,1:hp.length);
    hM = hp;
    hM.coef = hp.coef(:,:,:).*WE;
    T(n+1,:) = hM;
end

TT = ctranspose(T);
S = TT*T;
%only z^(q*n) terms can be nonzero
%force the rest to zero
S = down(S,q);
S = upsamp(S,q);