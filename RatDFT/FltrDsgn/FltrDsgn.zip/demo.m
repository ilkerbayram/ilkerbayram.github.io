%demonstration for 'MakeTight.m'
close all;

%sampling factors

p = 2;
q = 3;
%number of vanishing moments
vm = 4;

%An allowed snugness tolerance
Tol = 0.001;

%Nonsymmetric filter design using Algorithm 2 in the paper
inc = 1;
max_length = 25;

h = MakeTight(p,q,vm,max_length,Tol,inc);

%Symmetric filter design using the modification of Algorithm 2 in the paper
max_length = 29;
inc = 2;
hSym = MakeTightSym(p,q,vm,max_length,Tol,inc);


figure;
subplot(2,1,1);
stem(1:length(h),h);
title('Filter designed using "MakeTight"');

[H,w] = freqz(h);
subplot(2,1,2);
plot(w/pi,abs(H));xlabel('\omega/\pi');

figure;
subplot(2,1,1);
stem(1:length(hSym),hSym);
title('Filter Designed Using "MakeTightSym"');

[H,w] = freqz(hSym);
subplot(2,1,2);
plot(w/pi,abs(H));xlabel('\omega/\pi');