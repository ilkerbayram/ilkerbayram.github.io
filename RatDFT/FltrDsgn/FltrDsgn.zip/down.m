function [g] = down(h,M)
%downsamples the Laurent polynomial h by M
N = h.min;
K = (N  + mod(-N,M))/M;

P = K*M - N + 1;
q = h.coef(:,:,P:M:end);
g = mpoly(0,0);
g.coef = q;
g.min = K;