function [h] = HPoly(hp,p,q)
%h, obtained from the polyphase vector,
%given sampling factors {p,q}
%H(z) = \sum_{k=0}^{p-1} z^(-qk) H_k(z^p)
h = mpoly(0,0);
g = mpoly(0,0);
for k = 0:p-1,
    g = upsamp(hp(1,k+1),p);
    g.min = g.min + k*q;
    h = h + g;
end