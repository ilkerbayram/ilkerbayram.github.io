function [hpoly] = PolyH(h,p,q)
%polyphase vector for h, given sampling factors {p,q}
%H(z) = \sum_{k=0}^{p-1} z^(-qk) H_k(z^p)
m = h.min;
hpoly = mpoly(0,0);
for k = 0:p-1,
    h.min = m - q*k;
    g = down(h,p);
    hpoly(1,k+1) = g;
end