function [AppH] = SymApprox(h,p,q,vm,N)
%N : length of approximation
%vm : %number of vanishing moments
%h : filter as an mpoly object

% get the coefficients depending on type 
if mod(N,2) == 1,
    %type I
    K = (N-1)/2;
    h = trim(h,[-K,K]);
else
    %type II
    K = N/2-1;
    h = trim(h,[-K,K+1]);
end
A(1:h.length) = h.coef(1,1,1:end);
A = A';
  
fac = conv(ones(1,p)/p,ones(1,q)/q);
f=1;
for n=1:vm,
    f=conv(f,fac);
end

len_x = N-length(f)+1;
V = convmtx(f',len_x);

X = V\A;
APP = V*X;
co(1,1,1:length(APP)) = APP(1:end);

AppH = mpoly(0,0);
AppH.coef = co;
AppH.min = -K;