function [g] = MakeTightSym(p,q,vm,max_length,Tol,inc);
%[g] = MakeTight(p,q,vm,max_length,Tol,inc);
%gives the filter h that generates the {p,q} DFT-Modulated FB
%p, q: sampling factors
%vm : number of vanishing moments
%max_length = maximum length allowed 
%Tol : frame bound ratio tolerance
%inc : Amount of increase in filter length with each iteration
%inc is supposed to be an even integer

inc = inc + mod(inc,2); %make sure inc is even.

h = InitH(p,q,vm);

MAX_ITER = 10000;

len = h.length+inc;
if max_length <= h.length,
    max_length = 2*h.length;
end
%first iteration uses a large number of terms
terms1 = 40;
h2 = SQ(h,p,q,terms1);
h = SymApprox(h2,p,q,vm,len);

FrmBndRatio = 2;
terms = 5;

iter = 0;

while FrmBndRatio > 1 + Tol, 
    h2 = SQ(h,p,q,terms);
    h = SymApprox(h2,p,q,vm,len);
    h.coef = real(h.coef);
    [S,T] = PolyMatH(h,p,q);
    [A,B] = FrmBnds(S,50);
    FrmBndRatio = B/A
    if len + inc <= max_length,
        len = len + inc;
    elseif len + 2 <= max_length,
        len = len + 2;
    end
    iter = iter + 1;
    if iter > MAX_ITER,
        warning('Maximum number of iterations reached, exiting');
        break
    end
end
g(1:h.length) = h.coef(1,1,1:end);
g = real(g);
g = sqrt(p)*g/sum(g);