function [NewH] = SQ(h,p,q,MAX_ITER)

[S,P] = PolyMatH(h,p,q);
[A,B] = FrmBnds(S,50);

C = 2/(A+B);

Y = mpoly(eye(p),0);

T = Y - C*S;

Tn = mpoly(eye(p),0);

for n=1:MAX_ITER,
    Tn = Tn*T;
    coef = factorial(2*n)/[(factorial(n)^2)*2^(2*n)];
    Y = Y + coef*(Tn);
end

hp2 = sqrt(C)*P*Y;

NewH = HPoly(hp2,p,q);