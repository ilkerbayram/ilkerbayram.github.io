function [g] = upsamp(h,M)
%upsamples the Laurent polynomial h by M
N = (h.min)*M;
q(:,:,1:M:(h.length-1)*M+1) = h.coef(:,:,1:end);
g = mpoly(0,0);
g.coef = q;
g.min = N;