%demonstratiomn for the 2-dimensional transforms derived from 
%DFT-Modulated FBs
close all;

%load the filter 'h' for p=4, q=5 and 4 vanishing moments
load P4Q5V4;
%synthesis filter if the time reverse of 'h'
g = h(end:-1:1);%this doesn't matter in this case since 'h' is symmetric

x = double(imread('house.bmp'));

%%%check perfect reconstruction for 5 stages%%%

L = 5;
%analysis
coef = DIRDWT2D(x,h,p,q,L);

%reconstruction
y = IDIRDWT2D(coef,g,p,q);
y = y(1:size(x,1), 1:size(x,2));

figure;
subplot(2,1,1);
imshow(x,[]);title('Original Image');
subplot(2,1,2);
imshow(y,[]);title('Frame Operator Applied to the Original Image');

%difference image
diff = x - y;
max(abs(diff(:)))

%some of the directional synthesis functions

L = 2;
S = 128;

ze = zeros(S,S);
coefz = DIRDWT2D(ze,h,p,q,L);


figure;
img = zeros(S*5,S*5);
for r = 1:5,
    in1 = (r-1)*S + 1;
    for c = 1:5,
        cz = coefz;
        cz{L}{r,c}(round(end/2),round(end/2)) = 1;
        di = IDIRDWT2D(cz,g,p,q);
        di = di(1:S,1:S);
        in2 = (c-1)*S+1;
        img(in1:in1+S-1,in2:in2+S-1) = di;   
    end
end

imshow(img,[])

% figure;
% for n = 1:3,
%     cz = coefz;
%     cz{3}{2,n}(round(end/2),round(end/2)) = 1;
%     di = IDIRDWT2D(cz,g,p,q);
%     di = di(1:size(x,1),1:size(x,2));
%     subplot(2,2,n+1);
%     imshow(di,[]);
% end
% cz = coefz;
% cz{3}{1,2}(round(end/2),round(end/2)) = 1;
% di = IDIRDWT2D(cz,g,p,q);
% di = di(1:size(x,1),1:size(x,2));
% subplot(2,2,1);
% imshow(di,[]);
