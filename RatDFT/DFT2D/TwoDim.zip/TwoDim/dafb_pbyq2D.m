function [coef2] = dafb_pbyq2D(x,h,p,q);
%nonorthonormal directional afb for DFT-mod FB

W=exp(j*2*pi/q);

hr = h;
for r = 1:q,
    hc = h;
    for c = 1:q,
        a = upfirdn(x,hc,1,p);
        a = upfirdn(a.',hr,1,p);
        coef{r,c} = a.';
        hc=hc.*W.^(0:length(h)-1);
    end
    hr=hr.*W.^(0:length(h)-1);    
end

mid = ceil(q/2);
for r = 2:mid,
    rc = mod(-(r-1),q)+1;
    for c = 1:q,
        cc = mod(-(c-1),q)+1;
        a1 = coef{r,c};
        a2 = coef{rc,cc};
        coef2{r,c} = (a1+a2)/sqrt(2);  
        coef2{rc,cc} = i*(-a1+a2)/sqrt(2);
    end
end

r = 1;
rc = 1;
for c = 2:mid,
    cc = mod(-(c-1),q)+1;
    a1 = coef{r,c};
    a2 = coef{rc,cc};
    coef2{r,c} = (a1+a2)/sqrt(2);        
    coef2{rc,cc} = i*(-a1+a2)/sqrt(2);
end
coef2{1,1} = coef{1,1};

if mod(q,2) == 0,
    r = q/2+1;
    rc = q/2+1;
    for c = 2:mid,
        cc = mod(-(c-1),q)+1;
        a1 = coef{r,c};
        a2 = coef{rc,cc};
        coef2{r,c} = (a1+a2)/sqrt(2);        
        coef2{rc,cc} = i*(-a1+a2)/sqrt(2);
    end
    coef2{r,r} = coef{r,r};
    coef2{1,r} = coef{1,r};
    coef2{r,1} = coef{r,1};
end
    
