function [coef] = DIRDWT2D(x,h,p,q,max_level)
%DWT for DFT modulated FB (p/q) case
%x : input signal
%h : lowpass filter
%max_level : number of stages


y=x;

for n=1:max_level,
    c = dafb_pbyq2D(y,h,p,q);
    y = c{1};
    c{1} = [];
    coef{n} = c;    
end
c{1} = y;
coef{max_level} = c;