function [x,coef]= dsfb_pbyq2D(coef2,g,p,q);
%nonperiodic directional synthesis fb for the tight frame
%c is formatted as the output of analysis counterpart


mid = ceil(q/2);
for r = 2:mid,
    rc = mod(-(r-1),q)+1;
    for c = 1:q,
        cc = mod(-(c-1),q)+1;
        a1 = coef2{r,c};
        a2 = coef2{rc,cc};
        coef{r,c} = (a1+i*a2)/sqrt(2);  
        coef{rc,cc} = (a1-i*a2)/sqrt(2);
    end
end

r = 1;
rc = 1;
for c = 2:mid,
    cc = mod(-(c-1),q)+1;
    a1 = coef2{r,c};
    a2 = coef2{rc,cc};
    coef{r,c} = (a1+i*a2)/sqrt(2);        
    coef{rc,cc} = (a1-i*a2)/sqrt(2);
end
coef{1,1} = coef2{1,1};

if mod(q,2) == 0,
    r = q/2+1;
    rc = q/2+1;
    for c = 2:mid,
        cc = mod(-(c-1),q)+1;
        a1 = coef2{r,c};
        a2 = coef2{rc,cc};
        coef{r,c} = (a1+i*a2)/sqrt(2);        
        coef{rc,cc} = (a1-i*a2)/sqrt(2);
    end
    coef{r,r} = coef2{r,r};
    coef{1,r} = coef2{1,r};
    coef{r,1} = coef2{r,1};
end
    
W=exp(-j*2*pi/q);

N=length(g);

gr = g;
for r = 1:q,
    gc = g;
    for c = 1:q,
        a = upfirdn(coef{r,c},gc,p,1);
        a = upfirdn(a.',gr,p,1);
        a = a(N:end,N:end);
        y{r,c} = a.';
        gc = gc.*W.^(length(g)-1:-1:0);
    end
    gr = gr.*W.^(length(g)-1:-1:0);
end

x = 0*y{1,1};
for r = 1:q,
    for c = 1:q,
    x = x+y{r,c};
    end
end

