function [xx] = IDIRDWT2D(coef,g,p,q)
%inverse DWT for DFT modulated FB (p/q) case
%coef : coefficients from DWT_DFT
%g : lowpass filter

max_level = length(coef);

c = coef{max_level};
y = c{1,1};
for n = max_level:-1:1,
    c = coef{n};
    [N1,N2] = size(c{1,2});    
    c{1,1} = y(1:N1,1:N2);
    y = dsfb_pbyq2D(c,g,p,q);
end
xx = real(y);