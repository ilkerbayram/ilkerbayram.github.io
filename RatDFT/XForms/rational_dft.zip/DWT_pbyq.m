function [coef] = DWT_pbyq(x,h,p,q,max_lev)
%x : signal
%h : lowpass filter
%g : highpass filter
%p, q : rational FB parameters
%max_lev : the number of stages
a=x;
for n = 1:max_lev,
    c = analysis_pbyq_orth_nonperiodic(a,h,p,q);
    coef{n,2} = c{2};
    a = c{1};
end
coef{max_lev,1} = c{1};

function [c] = analysis_pbyq_orth_nonperiodic(x,h,p,q);
%nonperiodic analysis fb for orthonormal rational FB
c{1} = upfirdn(x,h{1},p,q);

c{2} = upfirdn(x,h{2},q-p,q);
