function [xx] = IDWT_DFT(coef,g,p,q)
%inverse DWT for DFT modulated FB (p/q) case
%coef : coefficients from DWT_DFT
%g : lowpass filter

max_level = size(coef,1);

y = coef{max_level,1};
for n=max_level:-1:1,
    for k = 2:q,
        c{k} = coef{n,k};
    end
    c{1} = y(1:length(c{2}));
    y = sfb_pbyq(c,g,p,q);
end
xx = y;

function [x]=sfb_pbyq(c,g,p,q);
%nonperiodic synthesis fb for the tight frame
%c is formatted as the output of analysis counterpart
%Columns of M hold the inverse filters

W=exp(-j*2*pi/q);

N=length(g);

for n = 1:q,
    y{n} = upfirdn(c{n},g,p,1);
    y{n}= y{n}(N:end);
    
    g = g.*W.^(length(g)-1:-1:0);
end

x = y{1};
for n = 2:q,
    x = x+y{n};
end