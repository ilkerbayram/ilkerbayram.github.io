function [coef] = DWT_DFT(x,h,p,q,max_level)
%DWT for DFT modulated FB (p/q) case
%x : input signal
%h : lowpass filter
%max_level : number of stages


y=x;

for n=1:max_level,
    c = afb_pbyq(y,h,p,q);
    for k = 2:q,
        coef{n,k} = c{k};
    end
    y = c{1};
end
coef{max_level,1} = c{1};

function [c] = afb_pbyq(x,h,p,q);
%nonorthonormal afb for DFT-mod FB

W=exp(j*2*pi/q);

for n = 1:q,
    c{n} = upfirdn(x,h,1,p);
    h=h.*W.^(0:length(h)-1);
end