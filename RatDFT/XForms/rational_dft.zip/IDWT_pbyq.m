function [y] = IDWT_pbyq(coef,h,p,q)
%coef : coefficient cell array from DWT_pbyq
%h : lowpass synthesis filter
%p, q : rational FB parameters

max_lev = size(coef,1);

a{1} = coef{max_lev,1};
for n = max_lev:-1:1,
    a{2} = coef{n,2};
    c = synthesis_pbyq_orth_nonperiodic(a,h,p,q);
    a{1} = c;
end
y = a{1};

function [x]=synthesis_pbyq_orth_nonperiodic(c,g,p,q);
%nonperiodic synthesis fb for orthonormal rational FB
%c is formatted as the output of analysis counterpart

N=length(g{1});

y{1} = upfirdn(c{1},g{1},q,1);
y{1} = y{1}(N:end);
y{1} = y{1}(1:p:end);

y{2} = upfirdn(c{2},g{2},q,1);
N = length(g{2});
y{2} = y{2}(N:end);
y{2} = y{2}(1:q-p:end);

M = max([length(y{1}), length(y{2})]);
for n = 1:2,
    y{n} = [y{n} zeros(1, M - length(y{n}))];
end

x = y{1}+y{2};