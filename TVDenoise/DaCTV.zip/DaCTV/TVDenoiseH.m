function [x,varargout] = TVDenoiseH(y,lamReach)
% solves the TV denoising problem
% min_x 0.5 || y -x ||_2^2 + lam*TV(x) 
%
% This algorithm is referred to as the 'homotopy method' in the manucsript.
%
% Ilker Bayram,
% Istanbul Technical University,
% September, 2013

N = length(y); % length of the signal


r = filter(1,[1 -1],y);
r = r(1:N);



iter = 1;
MAX_ITER = N;
TOL = 10^(-5);

dif = (1:N-1)*r(N)/N - r(1:N-1);

[lam,i] = max(abs(dif)); % determine the minimum lambda so that the tube contains the segment from 0 to r(N)

if lam < lamReach,
    lx = [0 N];
    ly = [0 r(N)];
    signs = [0 0];
    l = convert2line(lx,ly,N);
    x = l(2:end) - l(1:end-1);
    if nargout > 1,
        varargout{1} = [lx;ly;signs];
    end
    return
end
lx = [0 i N];
ly = [0 i*r(N)/N r(N)];
signs = [0 -1*sign(dif(i)) 0];

r1 = r - lam;r1(end) = r(end);r1 = [0 r1];
r2 = r + lam;r2(end) = r(end);r2 = [0 r2];

while lam > lamReach + TOL,
    iter = iter + 1;     
    % calculate the minimum lambda for each segment
    lamdif = lam;
    bestx = 0;
    besty = 0;
    bests = 0;
    for n = 1:(length(lx)-1),
        j = lx(n); k = lx(n+1);
         if k > j+1,
            c0 = ly(n); c1 = ly(n+1);
            s0 = signs(n);s1 = signs(n+1);
            % for the lower bound            
            for m = j+1:k-1,
                d = r1(m+1) - c0 - (c1-c0)*(m-j)/(k-j);
                e  = s0 + (m-j)*(s1-s0)/(k-j) - 1; 
                lamlow = d/e;
                if lamlow > 0,
                    if lamlow < lamdif,
                        lamdif = lamlow;
                        bestx = m;
                        besty = r1(m+1) + lamdif;
                        bests = 1;
                    end
                end
            end
            
            % for the upper bound            
            for m = j+1:k-1,
                d = r2(m+1) - c0 - (c1-c0)*(m-j)/(k-j);
                e  = s0 + (m-j)*(s1-s0)/(k-j) + 1; 
                lamhi = d/e;
                if lamhi > 0,
                    if lamhi < lamdif,
                        lamdif = lamhi;
                        bestx = m;
                        besty = r2(m+1) - lamdif;
                        bests = -1;
                    end
                end
            end
            
        end
        
    end
        
    if (lam - lamdif) < lamReach,
        lamdif = lam - lamReach;
        lam = lamReach;
        ly = ly + signs.*lamdif;
        r1 = r - lam;r1(end) = r(end);r1 = [0 r1];
        r2 = r + lam;r2(end) = r(end);r2 = [0 r2];
    
        break;
    end
    
        
    lam = lam - lamdif;
    ly = ly + signs.*lamdif;
    ind = sum(bestx > lx);
    lx = [lx(1:ind) bestx lx(ind+1:end)];
    ly = [ly(1:ind) besty ly(ind+1:end)];
    signs = [signs(1:ind) bests signs(ind+1:end)];
    r1 = r - lam;r1(end) = r(end);r1 = [0 r1];
    r2 = r + lam;r2(end) = r(end);r2 = [0 r2];    
    
end

l = convert2line(lx,ly,N);
x = l(2:end) - l(1:end-1);
if nargout > 1,
    varargout{1} = [lx;ly;signs];
end