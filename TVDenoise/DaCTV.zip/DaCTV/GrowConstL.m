function [line] = GrowConstL(y,line,lam,M)% inputs
% An implementation of Algorithm 1 from the manucsript
%
% y : data
% line : holds the current solution
% lam : current lambda -- it is assumed that the weight vector is constant,
%       save for lam(K) (= 0)
% K : index of the lambda to be increased from 0 to lam
%
% Ilker Bayram,
% Istanbul Technical University,
% September, 2013

TOL = 10^(-3);
K = line(1,M);

fac = 1;
L = line(1,M-1);
R = line(1,M+1);
sL = line(2,M-1);
sR = line(2,M+1);
t = sL + (K-L)*(sR-sL)/(R-L);
if line(2,M) < t, % not a lower corner
    fac = -1;
elseif line(2,M) == t,
    line = [line(:,M-1) line(:,M+1)];
    return;    
end

y = fac*y;
line(2:3,:) = fac*line(2:3,:);

r = filter(1,[1 -1],y);
r = r(1:length(y)); % the running sum of the data

%left segment
[nLeft,Left] = CheckLeftConst(line,r,lam,M);

%right segment
[nRight,Right] = CheckRightConst(line,r,lam,M);

% left corner
LeftC = CheckLeftCornerConst(line,M);

% right corner
RightC = CheckRightCornerConst(line,M);

% node
Node = CheckNodeConst(line,M);

labels = {'Left','Right','LeftC','RightC','Node'};
lamK = 0;
while lamK < lam - TOL,
    epsis = [Left;Right;LeftC;RightC;Node];    
    [epsi,n] = min(epsis);
    if epsi > lam - lamK, % do nothing, just update the node
        line(2,M) = line(2,M) - (lam - lamK);
        break;
    end
    
    line(2,M) = line(2,M) - epsi;
    lamK = lamK + epsi;
        
    opt = labels{n};
    % now update
    switch opt
        case{'Node'} %we're done in this case
            line = [line(:,1:M-1) line(:,M+1:end)];
            lamK = lam;
        case{'Left'}
            %insert the new corner and update the information about the left
            %corner and the node lambda
            ek = [nLeft; r(nLeft)-lam;1];
            line = [line(:,1:M-1) ek line(:,M:end)];
            M = M+1;            
            %left segment
            [nLeft,Left] = CheckLeftConst(line,r,lam,M);                       
            % left corner
            LeftC = CheckLeftCornerConst(line,M);
            % node
            Node = CheckNodeConst(line,M);
            % right segment
            Right = Right-epsi;
            % right corner
            RightC = RightC-epsi;
        case{'LeftC'}
            %remove the corner and update the information about the left
            %corner, left segment and the node
            line = [line(:,1:M-2) line(:,M:end)];
            M = M-1;
            %left segment
            [nLeft,Left] = CheckLeftConst(line,r,lam,M);                       
            % left corner
            LeftC = CheckLeftCornerConst(line,M);
            % node
            Node = CheckNodeConst(line,M);
            % right segment
            Right = Right-epsi;
            % right corner
            RightC = RightC-epsi;
        case{'Right'}
            %insert the new corner and update the information about the
            %right corner and the node          
            ek = [nRight; r(nRight)-lam;1];
            line = [line(:,1:M) ek line(:,M+1:end)];            
            %right segment
            [nRight,Right] = CheckRightConst(line,r,lam,M);                       
            % left corner
            RightC = CheckRightCornerConst(line,M);
            % node
            Node = CheckNodeConst(line,M);
            % left segment
            Left = Left-epsi;
            % left corner
            LeftC = LeftC-epsi;
        case{'RightC'}
            %remove the corner and update the information about the left
            %corner, left segment and the node
            line = [line(:,1:M) line(:,M+2:end)];
            % right segment
            [nRight,Right] = CheckRightConst(line,r,lam,M);
            % right corner
            RightC = CheckRightCornerConst(line,M);
            % node
            Node = CheckNodeConst(line,M);
            % left segment
            Left = Left-epsi;
            % left corner
            LeftC = LeftC-epsi;
    end
end

line(2:3,:) = fac*line(2:3,:);

function [ind,epsi] = CheckLeftConst(line,r,lam,M)

K  = line(1,M);
L = line(1,M-1);

if K-L < 2,
    ind = 0;
    epsi = Inf;
    return;
end

sK = line(2,M);
sL = line(2,M-1);
i = 1:K-L-1;
k = i+L;
epsis = (sK-sL) - (K-L)*(r(k) - lam - sL)./i;
[epsi,ind] = min(epsis);
ind = ind + L;

function [ind,epsi] = CheckRightConst(line,r,lam,M)

K  = line(1,M);
R = line(1,M+1);

if R-K < 2,
    ind = 0;
    epsi = Inf;
    return;
end

sK = line(2,M);
sR = line(2,M+1);
i = K-R+1:-1;
k = i+R;
epsis = (sK-sR) - (K-R)*(r(k) - lam - sR)./i;
[epsi,ind] = min(epsis);
ind = ind + K;

function [epsi] = CheckLeftCornerConst(line,M)

K  = line(1,M);
L = line(1,M-1);

if line(3,M-1) > -0.5, % L is not an upper corner
    epsi = Inf;
    return;
end

sK = line(2,M);
sL = line(2,M-1);
sL2 = line(2,M-2);
L2 = line(1,M-2);
epsi = (sK - sL) - (K-L)*(sL - sL2)/(L-L2);

function [epsi] = CheckRightCornerConst(line,M)

K = line(1,M);
R = line(1,M+1);

if line(3,M+1) > -0.5, % L is not an upper corner
    epsi = Inf;
    return;
end
   
sK = line(2,M);
sR = line(2,M+1);
sR2 = line(2,M+2);
R2 = line(1,M+2);
epsi = (sK - sR) - (K-R)*(sR2 - sR)/(R2-R);

function [epsi] = CheckNodeConst(line,M)

K = line(1,M);
L = line(1,M-1);
R = line(1,M+1);
   
sK = line(2,M);
sL = line(2,M-1);
sR = line(2,M+1);

epsi = ( (L-K)*(sR - sK) + (R-K)*(sK - sL) ) / (R-L);