function [x] =  HybridTV(y,lam,M)
% solves the TV denoising problem
% min_x 0.5 * || y -x ||_2^2 + lam * TV(x) 
% using Algorithm 3 in 'A Divide-and-Conquer Algorithm for 1D Total
% Variation Denoising'
%
% Ilker Bayram,
% Istanbul Technical University,
% September, 2013


N = length(y);
ind = 0;
% run TVdenoise on segments of length M
for n = 1:M:N,
    ind = ind+1;
    D = min(n+M-1,N);
    [x,lines{ind}] = TVDenoiseH(y(n:D),lam);    
end

% now merge them
Cntr = ind;
while Cntr > 1,
    L = 1;
    n = 1;
    while n < Cntr,        
        line1 = lines{n};
        M = size(line1,2);
        line2 = lines{n+1};
        line2(1,:) = line2(1,:) + line1(1,end);
        line2(2,:) = line2(2,:) + line1(2,end);
        line1 = [line1 line2(:,2:end)];
        len = line1(1,end);
        line1 = GrowConstL(y(L:L+len-1),line1,lam,M);
        L = L + len;
        lines{n} = line1;
        lines(n+1) = []; % remove from the list of lines
        Cntr = Cntr - 1;
        n = n + 1;
    end    
end
line = lines{1};
l = convert2line(line(1,:),line(2,:),N);
x = l(2:end) - l(1:end-1);