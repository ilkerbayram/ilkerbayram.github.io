% Demonstration for the hybrid TV algorithm from the manuscript
% 'A Divide-and-Conquer Algorithm for 1D Total Variation Denoising'
%
% Ilker Bayram,
% Istanbul Technical University,
% September, 2013

clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

N = 2^15; %length of the input signal
K = 2^5; % number of jumps
sig = 0.05;

s = zeros(1,N);
P = ceil(rand(1,K)*N);
S = rand(1,K).*sign(randn(1,K));
s(P) = S;
%
x = filter(1,[1 -1],s);
x = x(1:N); % clean signal


y = x + sig*randn(size(x)); % observations

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

lam = 2*sig*sqrt(N); % lambda value used for weighting the regularization (the code assumes constant lambda)
M = 200; % this is the size of the subproblems solved by the homotopy method (see Alg. 3)

rec =  HybridTV(y,lam,M); 

figure;
plot(y);hold on;plot(rec,'r');
legend('Noisy Observation','Reconstruction');
axis tight;