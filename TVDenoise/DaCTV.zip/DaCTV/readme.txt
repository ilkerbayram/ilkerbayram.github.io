﻿Please see 'Demo.m' for a demonstration.

The main algorithm is 'HybridTV.m', which is an implementation of Alg 3 from the manuscript. It combines small size TV denoising problems solved by 'TVDenoiseH.m',
which is an implementation of the 'homotopy method' mentioned in the manuscript. The two algorithms communicate through a special structure which contains the 'corner points' of the running sum (the values and their indices). 

This collection of Matlab codes (possibly with updates) is also available at
' http://web.itu.edu.tr/ibayram/TVDenoise/ '

Ilker Bayram 
ibayram@itu.edu.tr 
Istanbul Technical University
September, 2013.