 function [l] = convert2line(lx,ly,N)
l = zeros(1,N);
for n = 2:length(lx),
    M = lx(n)-lx(n-1);
    ind = (lx(n-1)+1):lx(n);
    s = ly(n-1) + [(1:M)/M]*(ly(n) - ly(n-1));
    l(ind) = s;
end
l = [0 l];