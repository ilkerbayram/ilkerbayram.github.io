% Matlab code for Experiment-1 in the manuscript
% 'On the Convergence of the Iterated Shrinkage/Thresholding Algorithm with
% a Weakly Convex Penalty', Ilker Bayram, 2015.

clear all;
close all;
          
% the cost function used in Experiment-1       
Cost = @(y,H,tau,a,x)  0.5 * sum( (y - H*x).^2 ) + sum( (tau*abs(x) - a*(x.^2)/2).*(abs(x) < tau/a) + (1/(2*a))*tau^2*(abs(x)>= (tau/a))  );
% the threshold function used in Experiment-1          
Th = @(x,alp,tau,a) [abs(x) > (alp*tau)].*[abs(x) < (tau/a)].*sign(x).*[(abs(x) - alp*tau)/(1-alp*a)] + [abs(x) >= tau/a].*x;

K = 50; % length of the clean signal
x = (rand(K,1) < 0.2).*randn(K,1); % the underlying sparse signal

% construct the convolution matrix H
H = convmtx([0.3 1 0.3], K+10);
H = H(:,3:K+2);

E = eig(H'*H);

% parameters for TwIST
E1 = min(E);
EM = max(max(E),1);
Kap = E1/EM;
rhoTw = (1-sqrt(Kap))/(1+sqrt(Kap));
twistalp = rhoTw^2 + 1;
twistbet = 2*twistalp/(E1 +  EM);

% produce the observations
sig = 0.1;
y = H*x;
y = y + sig*randn(size(y));

% parameters of the penalty function
rho = min(E); 
tau = rho*sig*3; % we select the deadzone by taking into account the amount of noise

alpSD = 1/max(E); % alpha that guarantees strict descent referred to as \alpha0
alpMax = 2/(max(E) + rho); % maximum value of alpha referred to as \alpha1 in the manuscript

% obtain the limit for distance calculation
init = zeros(size(x));
z = init;
alp = alpMax;
MAX_ITER = 10000;
for iter = 1:MAX_ITER,   
    z = Th(z + alpSD*H'*(y - H*z),alpSD,tau,rho);    
end
zlim = z; % zlim holds the limit referred to as x* in the manuscript

% variables used in ISTA, TwIST, FISTA
z = init;
z2 = z; 
z1 =  z;
zTw = z;
zFISTA = z;
zFISTA0 = z;
yFISTA = z;
tFISTA = 1;

MAX_ITER = 200;
costlist = zeros(1,MAX_ITER); % for ISTA with alpha0
costlist2 = zeros(1,MAX_ITER); % for ISTA with alpha1
costlistTW = zeros(1,MAX_ITER); % for TwIST
costFISTA = zeros(1,MAX_ITER); % for FISTA

dist = zeros(1,MAX_ITER); % for ISTA with alpha0
dist2 = zeros(1,MAX_ITER); % for ISTA with alpha1
distTW = zeros(1,MAX_ITER); % for TwIST
distFISTA = zeros(1,MAX_ITER); % for FISTA

for iter = 1:MAX_ITER,
    % ISTA with alpha0
    costlist(iter) = Cost(y,H,tau,rho,z2);
    dist(iter) = sum((z2-zlim).^2);
    z2 = Th(z2 + alpSD*H'*(y - H*z2),alpSD,tau,rho);
    
    % ISTA with alpha1
    costlist2(iter) = Cost(y,H,tau,rho,z);
    dist2(iter) = sum((z-zlim).^2);
    z = Th(z + alpMax*H'*(y - H*z),alpMax,tau,rho);

    % TwIST
    costlistTw(iter) = Cost(y,H,tau,rho,zTw);
    distTw(iter) = sum((zTw-zlim).^2);
    z0 = z1;
    z1 = zTw;    
    zTw = Th(zTw + alpSD*H'*(y - H*zTw),alpSD,tau,rho);
    zTw = (1-twistalp)*z0 + (twistalp - twistbet)*z1 + twistbet*zTw;
    
    % FISTA
    costlistFISTA(iter) = Cost(y,H,tau,rho,zFISTA);
    distFISTA(iter) = sum((zFISTA-zlim).^2);
    zFISTA0 = zFISTA;
    zFISTA = Th(yFISTA + alpSD*H'*(y - H*yFISTA),alpSD,tau,rho);
    tFISTA2 = (1 + sqrt(1+4*tFISTA^2))/2;
    yFISTA = zFISTA + ((tFISTA-1)/tFISTA2)*(zFISTA - zFISTA0);
    tFISTA = tFISTA2;    
end

% the rest are figures...

MS = 14;
MS2 = 8;

LW1 = 1;
LW2 = 2.5;

figure;
subplot(2,1,1);
plot(z,'o','MarkerSize',MS2);hold on;stem(x,'.','MarkerSize',MS);
legend('Estimated','True');
title('Reconstruction');

figure;
subplot(2,1,1);
plot(log(costlist),'--','LineWidth',LW1);
hold on;
plot(log(costlist2),'LineWidth',LW2);
plot(log(costlistTw),'LineWidth',LW1);
plot(log(costlistFISTA),'-.','LineWidth',LW1);
legend('\alpha_0','\alpha_1','TwIST','FISTA');
axis tight;
xlabel('Iterations');
ylabel('log(cost)');
title('History of the Cost');

subplot(2,1,2);
plot(log(dist),'--','LineWidth',LW1);
hold on;
plot(log(dist2),'LineWidth',LW2);
plot(log(distTw),'LineWidth',LW1);
plot(log(distFISTA),'-.','LineWidth',LW1);
legend('\alpha_0','\alpha_1','TwIST','FISTA');
xlabel('Iterations');
ylabel('log( || x - x* ||_2 )');
title('History of the Distance to the Limit');