% Matlab code for Experiment-2 in the manuscript
% 'On the Convergence of the Iterated Shrinkage/Thresholding Algorithm with
% a Weakly Convex Penalty', Ilker Bayram, 2015.

clear all;
close all;

% the cost function used in Experiment-2           
Cost = @(y,H,tau,x)  0.5 * sum( (y - H*x).^2 ) + tau*sum( ( x-floor(x) ).*( ceil(x) - x ) );

% the threshold function used in Experiment-2
Th = @(x,at) 0*[x <= at] ...
    + (x/(1-2*at) - at/(1-2*at)).*[x <= (1-at)].*[at < x] ...
    + 1*[x <= (1+at)].*[(1-at) < x] ...
    + ( x/(1-2*at) + 1 - (1+at)/(1-2*at) ).*[ x <= (2-at) ].*[ (1+at) < x ] ...
    + 2*[x <= (2+at)].*[(2-at) < x] ...
    + ( x/(1-2*at) + 2 - (2+at)/(1-2*at) ).*[ x <= (3-at) ].*[ (2+at) < x ] ...
    + 3*[x <= (3+at)].*[(3-at) < x] ...
    + ( x/(1-2*at) + 3 - (3+at)/(1-2*at) ).*[ x <= (4-at) ].*[ (3+at) < x ] ...
    + 4*[(4-at) < x];


K = 75; % length of the underlying signal
BL = 3; % block length

% construct the convolution matrix F
F = convmtx([-0.3 1 -0.45], K+1);
F = F(:,3:K+2);

% construct the frame synthesis operator G
G = convmtx(ones(BL,1),size(F,2));
G = G(1:size(F,2),1:BL:end);

H = F*G; % this is the observation matrix

c = round(4*(rand(size(H,2),1))); % the underlying clear coefficients

E = eig(H'*H); % eiegnvalues of the observation matrix

% parameters for TwIST
E1 = min(E);
EM = max(max(E),1);
Kap = E1/EM;
rhoTw = (1-sqrt(Kap))/(1+sqrt(Kap));
twistalp = rhoTw^2 + 1; 
twistbet = 2*twistalp/(E1 +  EM);

% produce the observations
sig = 0.18;
y = H*c;
y = y + sig*randn(size(y));


tau = min(E)*0.45; % this is the weight of the penalty

alpSD = 1/max(E); % alpha that guarantees strict descent referred to as \alpha0
alpMax = 2/(max(E) + tau*2); % maximum value of alpha referred to as \alpha1 in the manuscript

% obtain the limit for distance calculation
init = zeros(size(c));
z = init;
alp = alpMax;
MAX_ITER = 10000;
for iter = 1:MAX_ITER,   
    z = Th(z + alpSD*H'*(y - H*z),alpSD*tau);    
end
zlim = z; % zlim holds the limit referred to as x* in the manuscript

% variables used in ISTA, TwIST, FISTA
z = init;
z2 = z; 
z1 =  z;
zTw = z;
zFISTA = z;
zFISTA0 = z;
yFISTA = z;
tFISTA = 1;

MAX_ITER = 100;

costlist = zeros(1,MAX_ITER); % for ISTA with alpha0
costlist2 = zeros(1,MAX_ITER); % for ISTA with alpha1
costlistTW = zeros(1,MAX_ITER); % for TwIST
costFISTA = zeros(1,MAX_ITER); % for FISTA

dist = zeros(1,MAX_ITER); % for ISTA with alpha0
dist2 = zeros(1,MAX_ITER); % for ISTA with alpha1
distTW = zeros(1,MAX_ITER); % for TwIST
distFISTA = zeros(1,MAX_ITER); % for FISTA

for iter = 1:MAX_ITER,
    % ISTA with alpha0
    costlist(iter) = Cost(y,H,tau,z2);
    dist(iter) = sum((z2-zlim).^2);
    z2 = Th(z2 + alpSD*H'*(y - H*z2),alpSD*tau);
    
    % ISTA with alpha1
    costlist2(iter) = Cost(y,H,tau,z);
    dist2(iter) = sum((z-zlim).^2);
    z = Th(z + alp*H'*(y - H*z),alpMax*tau);

    % TwIST
    costlistTw(iter) = Cost(y,H,tau,zTw);
    distTw(iter) = sum((zTw-zlim).^2);
    z0 = z1;
    z1 = zTw;    
    zTw = Th(zTw + alpSD*H'*(y - H*zTw),alpSD*tau);
    zTw = (1-twistalp)*z0 + (twistalp - twistbet)*z1 + twistbet*zTw;
    
    % FISTA
    costlistFISTA(iter) = Cost(y,H,tau,zFISTA);
    distFISTA(iter) = sum((zFISTA-zlim).^2);
    zFISTA0 = zFISTA;
    zFISTA = Th(yFISTA + alpSD*H'*(y - H*yFISTA),alpSD*tau);
    tFISTA2 = (1 + sqrt(1+4*tFISTA^2))/2;
    yFISTA = zFISTA + ((tFISTA-1)/tFISTA2)*(zFISTA - zFISTA0);
    tFISTA = tFISTA2;    
end


% the rest are figures...

MS = 14;
MS2 = 8;

LW1 = 1;
LW2 = 2.5;

hatz = (F'*F)\(F'*y);
figure;
subplot(2,1,1);
plot(hatz,'o','MarkerSize',MS2);hold on;stem(G*c,'.','MarkerSize',MS);
legend('LS','True');
axis([0.5 length(hatz)+0.5 -0.5 4.5]);
title('Least Squares Solution');
subplot(2,1,2);
plot(G*z,'o','MarkerSize',MS2);hold on;stem(G*c,'.','MarkerSize',MS);
legend('Est.','True');
axis tight;
title('Solution Obtained by the Formulation');


figure;
subplot(2,1,1);
plot(log(costlist),'--','LineWidth',LW1);
hold on;
plot(log(costlist2),'LineWidth',LW2);
plot(log(costlistTw),'LineWidth',LW1);
plot(log(costlistFISTA),'-.','LineWidth',LW1);
legend('\alpha_0','\alpha_1','TwIST','FISTA');
axis tight;
xlabel('Iterations');
ylabel('log(cost)');
title('History of the Cost');

subplot(2,1,2);
plot(log(dist),'--','LineWidth',LW1);
hold on;
plot(log(dist2),'LineWidth',LW2);
plot(log(distTw),'LineWidth',LW1);
plot(log(distFISTA),'-.','LineWidth',LW1);
legend('\alpha_0','\alpha_1','TwIST','FISTA');
xlabel('Iterations');
ylabel('log( || x - x* ||_2 )');
title('History of the Distance to the Limit');