function [ c ] = HaarDWT( x, J )
% function [ c ] = HaarDWT( x, J )
%
% applies the Haar DWT with J stages
%
% Input : 
% x : image whose size is divisible by 2^J
% J : number of stages
%
% Output :
% c : Haar DWT coefficients
%
% Ilker Bayram, Istanbul Teknik Universitesi, 2015

c = HaarAFB(x);
d = c;
for j = 2:J,
    x = d(1:end/2,1:end/2);
    d = HaarAFB(x);
    K = 2^(j-1);
    c(1:end/K,1:end/K) = d;
end

function [c] = HaarAFB(x)
% Analysis Filter Bank for the Haar Wavelet
c = [ ( x(:,1:2:end) + x(:,2:2:end) ) ( x(:,1:2:end) - x(:,2:2:end) )];
c = [ ( c(1:2:end,:) + c(2:2:end,:) ); ( c(1:2:end,:) - c(2:2:end,:) )];
c = c / 2;