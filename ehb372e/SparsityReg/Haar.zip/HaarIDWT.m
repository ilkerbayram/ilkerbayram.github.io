function [ x ] = HaarIDWT( c, J )
% function [ x ] = HaarIDWT( c, J )
%
% applies the Haar inverse DWT for J stages 
%
% Input : 
% c : DWT coefficients produced by HaarDWT
% J : number of stages
%
% Output :
% c : reconstructed image
%
% Ilker Bayram, Istanbul Teknik Universitesi, 2015

x = c;
for j = J:-1:1,
    K = 2^(j-1);
    c = x(1:end/K,1:end/K);
    x(1:end/K,1:end/K) = HaarSFB(c);
end

function [x] = HaarSFB(c)
% Synthesis Filter Bank for the Haar Wavelet
x = c;
% vertical processing
c1 = ( c(1:end/2,:) + c(end/2+1:end,:) ) / sqrt(2);
c2 = ( c(1:end/2,:) - c(end/2+1:end,:) ) / sqrt(2);
c(1:2:end,:) = c1;
c(2:2:end,:) = c2;

% horizontal processing
x(:,1:2:end) = ( c(:,1:end/2) + c(:,end/2+1:end) ) / sqrt(2);
x(:,2:2:end) = ( c(:,1:end/2) - c(:,end/2+1:end) ) / sqrt(2);