% This Demo file generates the observation matrix H, as well as the upper
% bound matrices to be used in DemoBivariateISTA.m
%
% In order to run this script, SeDuMi needs to be in the working path.
%
% Ilker Bayram,
% ibayram@itu.edu.tr,
% Istanbul Technical University, 2016

clear all;
close all;

tau = 0.5;
h = exp(tau*(0:-1:-10));
K = 100;
H = convmtx(h,K);
H = H(1:K,1:K);
HH = H' * H;
HH2 = HH + 10^(-20) * eye(size(HH,1));

%% least block upper bound (Sec III.A)
% number of blocks 
B = size(HH,1)/2;

% number of variables : 
nv = 3*B;
c = zeros(nv,1);
c(1:2*B) = 1;
bt = -c;
ct = vec(-HH2);
s = size(HH);
At = [];
for n = 1:size(HH,1),
    A = sparse(n,n,1,s(1),s(2));
    At = [At vec(-A)];
end
for n = 1:B,
    A = sparse([2*n-1;2*n],[2*n;2*n-1],[1;1],s(1),s(2));
    At = [At vec(-A)];
end
Ksed.s = size(HH,1);
[x,y,info] = sedumi(At,bt,ct,Ksed);


M1 = zeros(size(HH));
ind = 0;
for n = 1:size(HH,1),
    ind = ind + 1;
    A = sparse(n,n,1,s(1),s(2));
    M1 = M1 + y(ind) * A;
end
for n = 1:B,
    ind = ind+1;
    A = sparse([2*n-1;2*n],[2*n;2*n-1],[1;1],s(1),s(2));
    M1 = M1 + y(ind) * A;
end

%% block upper bound via Gershgorin theorem (Sec III.B)

M2 = zeros(size(HH));
for n = 1:2:size(HH,1)-1,
    b =  HH2(n,n+1);
    a1 = sum(abs(HH2(n,1:n))) + sum(abs(HH2(n,n+2:end)));
    a2 = sum(abs(HH2(n+1,1:n-1))) + sum(abs(HH2(n+1,n+1:end)));
    C = [a1 b; b a2];
    M2(n:n+1,n:n+1) = C;
end

%% least diagonal upper bound (this is used in ISTA)
 
c = ones(size(HH,1),1);
bt = -c;
ct = vec(-HH2);
s = size(HH);
At = [];
for n = 1:size(HH,1),
    A = sparse(n,n,1,s(1),s(2));
    At = [At vec(-A)];
end
Ksed.s = size(HH,1);
[x,y,info] = sedumi(At,bt,ct,Ksed);

D = zeros(size(HH));
ind = 0;
for n = 1:size(HH,1),
    ind = ind + 1;
    A = sparse(n,n,1,s(1),s(2));
    D = D + y(ind) * A;
end



%% check how tight the upper bound matrices are
e1 = eig(M1 - HH);
e2 = eig(M2 - HH);
e3 = eig(D - HH);

figure;
plot(e1);
hold on;
plot(e2,'r');
plot(e3,'k');
legend('M_1 - H'' * H','M_2- H'' * H','D- H'' * H','Location','SouthEast');
title('Eigenvalues of Difference Matrices');
%%

save DataMatrices H HH M1 M2 D