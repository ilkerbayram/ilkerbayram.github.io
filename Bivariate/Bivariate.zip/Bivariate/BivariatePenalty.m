function [x] = BivariatePenalty(z,a,b,c)
% bivariate penalty
A1 = [c -b]; 
A2 = [-b a];
eps = 10^(-5);
x = zeros(2,1);
if (abs(z(1)) < 1 + eps) && ((abs(z(2)) < 1 + eps)),
    % do nothing
else if (abs(z(1)) > 1) && ( abs(z(2) - (z(1) - sign(z(1))) * b / a ) < 1 + eps ),
        x(1) = ( z(1) - sign(z(1)) ) / a ;
    else if (abs(z(2)) > 1) && ( abs(z(1) - (z(2) - sign(z(2))) * b / c ) < 1 + eps),
            x(2) = ( z(2) - sign(z(2)) ) / c ;
        else for r = 0:1,
                for s = 0:1,
                    d = [ (-1)^r; (-1)^s ];                    
                    if (d(1) *  ( A1 * ( z - d ) ) > 0) && ( d(2) *  ( A2 * ( z - d ) ) > 0),
                        x  = [c -b; -b a] * (z-d) / (a*c-b^2);
                        break;
                    end
                end
            end
        end
    end
end