clear all;
close all;

%checks perfect reconstruction

%parameters of the wavelet transform -- see the manuscript for the details
p = 225;
q = 229;
r = 1;
s = 30;
bet = 0.8*r/s;
J = 100; % number of stages
gam = 7; % this is the chirp parameter
 

%input signal
x = randn(1,100000);

N = ceil(length(x)/2)*2;

tic
[F] = CreateFilters(N,p,q,r,s,bet,J); %without the chirp parameter
%[F] = CreateFilters(N,p,q,r,s,bet,J,gam); % with the chirp parameter
toc
tic
w = RAnDwt(x,p,q,r,s,J,F);
y = iRAnDwt(w,N,p,q,r,s,F);
toc
y = y(1:length(x));

figure;plot(x);hold on;plot(x-real(y),'r');%plot(imag(y(1:length(x))),'k');
max( abs ( x - y ) )

%check the Parseval condition
en = 0;
for n = 1:J,
    sub = w{n,1};
    en = en + sum(abs(sub).^2);
    sub = w{n,2};
    en = en + sum(abs(sub).^2);
end

sub = w{J+1,1};
en = en + sum(abs(sub).^2)
en2 = sum(abs(x).^2)