% experiment-3 from the manuscript

clear all;
close all;

[x,fs,NBITS]=wavread('Cardinal animals066');
x = x(13001:31000);
x = x';

x = x - mean(x);
x = [zeros(1,1000) x(:)' zeros(1,1000)];


p = 5;
q = 6;
r = 1;
s = 2;
bet = 0.8*r/s;
J = 20;


Par = 200;
[Fp] = CreateFilters(length(x),p,q,r,s,bet,J,Par);%filters for the positive chirp parameter
[Fn] = CreateFilters(length(x),p,q,r,s,bet,J,-Par);%filters for the negative chirp parameter


wp = RAnDwt(zeros(size(x)),p,q,r,s,J,Fp);

wn = wp;

MAX_ITER = 400;
lam = 2;
fac = 0.99;

w = RAnDwt(zeros(size(x)),p,q,r,s,J,Fp);
res = x;
yp = 0*x;
yn = yp;

LX = length(x);

h = waitbar(0,'Please wait...');
for iter = 1:MAX_ITER,
    waitbar(iter/MAX_ITER,h);    

    % peel off the significant positive-chirp atoms from
    % the residual
    res = x - yn - yp;    
    w2 = RAnDwt(res,p,q,r,s,J,Fp);
    w = wp;
    for k = 1:J,
        sub = w2{k,1} + 1i*w2{k,2};
        sub = max(abs(sub)-lam,0).*exp(1i*angle(sub));
        w{k,1} = real(sub) + w{k,1};
        w{k,2} = imag(sub) + w{k,2};
    end
    wp = w;   
    yp =  iRAnDwt(wp,LX,p,q,r,s,Fp); 
    
    % peel off the significant negative-chirp atoms from
    % the residual    
    res = x - yn - yp;      
    w2 = RAnDwt(res,p,q,r,s,J,Fn);
    w = wn;
    for k = 1:J,
        sub = w2{k,1} + 1i*w2{k,2};
        sub = max(abs(sub)-lam,0).*exp(1i*angle(sub));
        w{k,1} = real(sub) + w{k,1};
        w{k,2} = imag(sub) + w{k,2};
    end
    wn = w;    
    yn =  iRAnDwt(wn,LX,p,q,r,s,Fn); 
        
    %reduce the threshold
    lam = lam*fac;
    
    d = make2D(wp,p,q);
    subplot(2,1,1);
    imagesc(-abs(d));colormap(gray);title(num2str(iter));
    drawnow;
    
    d = make2D(wn,p,q);
    subplot(2,1,2);
    imagesc(-abs(d));colormap(gray);
    drawnow;
end
close(h);
close all;

FSz = 14;
figure;
subplot(2,1,2);
S0 = spectrogram(x,300,290,2048);
imagesc(-abs(S0(end:-1:1,:)));
colormap(gray); 
xlabel('Time');
ylabel('Frequency');


figure;
subplot(2,1,2);
S0 = spectrogram(yp,300,290,2048);
imagesc(-abs(S0(end:-1:1,:)));
colormap(gray); 
xlabel('Time');
ylabel('Frequency');

figure;
subplot(2,1,2);
S0 = spectrogram(yn,300,290,2048);
imagesc(-abs(S0(end:-1:1,:)));
colormap(gray); 
xlabel('Time');
ylabel('Frequency');

X =  fft(x);
X(end/2:end)=0;
xa = ifft(X);
figure(1);
subplot(2,1,1);
plot(2*abs(xa)); hold on;plot(-2*abs(xa));
axis tight;
title('Original');

X =  fft(yp);
X(end/2:end)=0;
xa = ifft(X);
figure(2);
subplot(2,1,1);
plot(2*abs(xa)); hold on;plot(-2*abs(xa));
axis tight;
title('Positive Chirp Component');

X =  fft(yn);
X(end/2:end)=0;
xa = ifft(X);
figure(3);
subplot(2,1,1);
plot(2*abs(xa)); hold on;plot(-2*abs(xa));
axis tight;
title('Negative Chirp Component');

%soundsc(x,fs); %original
%soundsc(yp,fs); %positive chirp component
%soundsc(yn,fs); %negative chirp component