% experiment-1 from the manuscript

clear all;
close all;

% -- 275/2799 is approximately (1/2)^(1/48)

[x,fs,nbits] = wavread('vsc22K'); %downloaded, at some point, from Prof. Judy Brown's webpage
x = x(1:50000);
x = [zeros(1,1000) x(:)' zeros(1,1000)];
NN = length(x);
p = 275;
q = 279;
r = 1;
s = 10;
bet = 0.95*r/s;
J = 350;

[F] = CreateFilters(length(x),p,q,r,s,bet,J);
w = RAnDwt(x,p,q,r,s,J,F);

for k = 1:J,
    sub = abs(w{k,1} + 1i*w{k,2});
    sub2 = IntCubic(sub,46,41);
    mag{k}= sub2';
end
    
d = make2D(w,p,q);
imagesc(-abs(d));colormap(gray);
y = randn(size(x));


MAX_ITER = 50;
h = waitbar(0,'Please wait...');
for iter = 1:MAX_ITER,
    waitbar(iter/MAX_ITER,h);    
   
    w2 = RAnDwt(y,p,q,r,s,J,F);

    d = make2D(w2,p,q);
    imagesc(-abs(d));colormap(gray);title(num2str(iter));
    drawnow;
    m = 8;
    for k = J-m+1:J,
        w2{k,1} = 0*w2{k,1};
        w2{k,2} = 0*w2{k,2};
    end
    for k = 1:J-m,
        sub1 = mag{k+m};
        sub2 = w2{k,1} + 1i*w2{k,2};
        len = min(length(sub1),length(sub2));
        sub1 = sub1(1:len);
        sub2 = sub2(1:len);
        sub2 = abs(sub1).*exp(1i*angle(sub2));
        
        w2{k,1}(1:len) = real(sub2(1:len));
        w2{k,2}(1:len) = imag(sub2(1:len));
        if length(w2{k,1})> len,
            w2{k,1}(len+1:end)=0;
            w2{k,2}(len+1:end)=0;
        end
    end
    w2{end,1} = 0*w2{end,1};
        
    y = iRAnDwt(w2,NN,p,q,r,s,F); 
end
close(h);
close all
figure;subplot(1,2,1);
d = make2D(w,p,q);d = d/max(abs(d(:)));
imagesc(-sqrt(abs(d)));colormap(gray);
xlabel('Time');
ylabel('Subbands');
title('Original');

subplot(1,2,2);
w2 = RAnDwt(y,p,q,r,s,J,F);
d = make2D(w2,p,q);d = d/max(abs(d(:)));
imagesc(-sqrt(abs(d)));colormap(gray);
xlabel('Time');
ylabel('Subbands');
title('Transposed');

%soundsc(x,fs); %original
%soundsc(y,fs); %transposed