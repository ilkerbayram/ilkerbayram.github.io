function [w] = RAnDwt(x,p,q,r,s,J,F)
% x : input signal
% p,q,r,s : sampling parameters
% J : number of levels (redundant -- to be removed)
% F : filters from 'CreateFilters'
%Ilker Bayram
%Istanbul Teknik Universitesi
%Jan, 2012

% make sure 'x' is a row vector of even length
x = x(:);x = x.';
L = length(x); 
N = L + mod(L,2); % x should be even length
x = [x zeros(1,N-L)];
clear L;

if (N * ((p/q)^J))*r/(2*s) < 2,
    error('Too many subbands -- Reduce ''J''');
end
    
X = fft(x)/sqrt(N);

%the sampling factors

PQ = zeros(J,2);
RS = zeros(J,2);
for k = 1:J,
    p0 = ceil(N * ((p/q)^k) ); p0 = p0 + mod(p0,2); % make sure p0 is even
    PQ(k,1) = p0;
    RS(k,1) = round(N * ( (p/q)^(k-1) ) * r/(2*s));    
end
PQ(1,2) = N;
PQ(2:end,2) = PQ(1:end-1,1);
RS(1:end,2) = PQ(1:end,2)/2;
 
PQ = [1 1;PQ];
PQk = 1;

for n = 1:J,
    PQk = PQk*PQ(n,1)/PQ(n,2);
    
    pp = PQ(n+1,1);qq = PQ(n+1,2);
    rr = RS(n,1);ss = RS(n,2);
             
    G = F{n,1};
    f = F{n,2};
    
    % positive frequencies
    dd = length(G);
    sub = G(1:end).*X(1+(f{1}:f{1}+dd-1));
    N1 = N*PQk*rr/(2*ss);
    N1 = round(N1);
    sub2 = zeros(1,N1);    
    sub2(1:length(sub)) = sub;
    d = mod(f{1},N1);    
    sub2 = circshift(sub2.',d);
    sub2 = ifft(sub2);
    
    % negative frequencies
    g1 = N - f{1};    
    g4 = N - f{1} - dd + 1;
    sub = conj(G(end:-1:1)).*X(1+(g4:g1));
    sub3 = zeros(1,N1);
    sub3(end-length(sub)+1:end) = sub;
    sub3 = circshift(sub3.',-(d-1));
    sub3 = ifft(sub3);
        
    w{n,1} = (sub2 + sub3)*sqrt(N1/2);
    w{n,2} = 1i*(sub2 - sub3)*sqrt(N1/2);
    
    
end
H = F{J+1};
N1 = PQ(J+1,1); 
sub = [X(1+(0:f{2}-1)).*H(1+(0:f{2}-1)) 0 X(end-f{2}+2:end).*H(f{2}:-1:2)];
sub2 = ifft(sub)*sqrt(N1);
w{J+1,1} = (sub2);