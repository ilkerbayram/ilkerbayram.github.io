% experiment-1 from the manuscript

clear all;
close all;

% -- 84/89 is approximately (1/2)^(1/12)
% -- 34/35 is approximately (1/2)^(1/24)
% -- 86/87 is approximately (1/2)^(1/60)
% -- 138/139 is approximately (1/2)^(1/96)
% -- 275/279 is approximately (1/2)^(1/48)
% -- 49/55 is approximately (1/2)^(2/12)
% -- 221/295 is approximately (1/2)^(5/12)


%[x,fs,nbits] = wavread('vsc44K');x = x(1:110000);
[x,fs,nbits] = wavread('pianochord'); % sample obtained from : http://www.univie.ac.at/nonstatgab/cqt/

x = [zeros(1,1000) x(:)' zeros(1,1000)];
NN = length(x);
p = 275;
q = 279;
r = 1;
s = 20;
bet = 0.95*r/s;
J = 400;

e = 49;
f = 55;
r2 = r*f;
s2 = s*e;

tic
[F] = CreateFilters(length(x),p,q,r,s,bet,J);

w = RAnDwt(x,p,q,r2,s2,J,F);
w2 = w;
M = 8;
for k = 1+M:J,
    sub = w{k,1} + 1i*w{k,2};
    w2{k-M,1} = w{k,1};
    w2{k-M,2} = w{k,2};
end
for k = J-M-1:J,
    w2{k-M,1} = 0*w{k,1};
    w2{k-M,2} = 0*w{k,1};
end

y = iRAnDwt(w2,NN,p,q,r,s,F); 

toc

w3 = RAnDwt(y,p,q,r2,s2,J,F);


subplot(1,2,1);
d = make2D(w2,p,q);
imagesc(-abs(d));colormap(gray);
xlabel('Time');
ylabel('Subbands');
title('Original');

subplot(1,2,2);
d = make2D(w3,p,q);
imagesc(-abs(d));colormap(gray);
xlabel('Time');
ylabel('Subbands');
title('Transposed');

%soundsc(x,fs); % original
%soundsc(y,fs); % transposed 