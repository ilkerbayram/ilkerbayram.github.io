function [x] = iRAnDwt(w,N,p,q,r,s,F)
% w : Coefficients from RanDwt
% N : length of the output
% p,q,r,s : sampling parameters
% bet : the beta parameter, determines the Q-factor as Q = (2-bet)/bet
% F : filters from 'CreateFilters'
%
%Ilker Bayram
%Istanbul Teknik Universitesi
%Jan, 2012

% make sure 'x' is a row vector of even length
N = N + mod(N,2);  
X = zeros(1,N);
J = size(w,1)-1;

%the sampling factors

PQ = zeros(J,2);
RS = zeros(J,2);
for k = 1:J,
    p0 = ceil(N * ((p/q)^k) ); p0 = p0 + mod(p0,2); % make sure p0 is even
    PQ(k,1) = p0;
    RS(k,1) = round(N * ( (p/q)^(k-1) ) * r/(2*s));    
end
PQ(1,2) = N;
PQ(2:end,2) = PQ(1:end-1,1);
RS(1:end,2) = PQ(1:end,2)/2;
 
PQ = [1 1;PQ];
PQk = 1;


for n = 1:J,
    PQk = PQk*PQ(n,1)/PQ(n,2);
    
    pp = PQ(n+1,1);qq = PQ(n+1,2);
    rr = RS(n,1);ss = RS(n,2);
        
    G = conj(F{n,1});
    f = F{n,2};  
    
    % positive frequencies
    N1 = N*PQk*rr/(2*ss);
    N1 = round(N1);
    d = mod(f{1},N1);
    
    
    sub = (fft(w{n,1} - 1i*w{n,2},N1))/sqrt(2*N1);
    sub = circshift(sub,-d);
    sub = sub.';    
    dd = length(G);
    X(1+(f{1}:f{1}+dd-1)) = X(1+(f{1}:f{1}+dd-1)) + G.*sub(1:dd);
    
    % negative frequencies
    g1 = N - f{1};    
    g4 = N - f{1} - dd + 1;     
    sub = (fft(w{n,1} + 1i*w{n,2},N1))/sqrt(2*N1);
    sub = circshift(sub,d-1);
    sub = sub.';    
    X(1+(g4:g1)) = X(1+(g4:g1)) + conj(G(end:-1:1)).*sub(end-dd+1:end);
    
    
end
sub = fft(w{J+1,1})/sqrt(length(w{J+1,1}));
H = F{J+1,1};  
X(1:f{2}) = X(1:f{2}) + sub(1:f{2}).*H(1:f{2});
X(end-f{2}+2:end) = X(end-f{2}+2:end) + sub(end-f{2}+2:end).*H(f{2}:-1:2);
x = ifft(X)*sqrt(N);
x = real(x);